# EXAM OS Android Wrapper

This Android project packages the original `EXAM OS.html` inside an Android WebView.

## Important

- The original `EXAM OS.html` is copied into `app/src/main/assets/` **unchanged**.
- The wrapper does not rewrite, patch, minify, or otherwise modify the HTML/CSS/JS.
- JavaScript, DOM storage, local file access, and Internet access are enabled for the existing app behavior.
- The project is ready to build with GitHub Actions; no Android Studio installation is required on the user's phone.

## GitHub Actions

1. Upload this project folder's contents to a GitHub repository.
2. Push to `main` or `master`, or open **Actions → Build EXAM OS APK → Run workflow**.
3. After the run completes, open the workflow run and download the `EXAM_OS_APK` artifact.
4. The artifact contains `app-debug.apk`.

The workflow uses JDK 17, Gradle 8.9, and Android Gradle Plugin 8.7.3.
