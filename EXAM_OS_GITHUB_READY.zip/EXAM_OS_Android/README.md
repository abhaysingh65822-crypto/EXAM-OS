# EXAM OS Android Wrapper

This Android project packages the original `EXAM OS.html` inside an Android WebView.

IMPORTANT: The original HTML file is copied into `app/src/main/assets/` unchanged.
The wrapper does not rewrite or patch the HTML/CSS/JS.

The WebView enables JavaScript, DOM storage, local file access, and Internet access so the existing app can use its current browser APIs, external CDN resources, and Gemini endpoint.
