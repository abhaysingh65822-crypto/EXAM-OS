# EXAM OS — Autonomous AI Exam Preparation & Personal Study Operating System

An autonomous, mobile-first, intelligent personal exam preparation system for Android built with modern Jetpack Compose, Kotlin Coroutines & Flow, Room Database, and Google Gemini API integration.

Unlike traditional study trackers or passive todo apps, **EXAM OS** requires only the minimum input to discover, construct, and execute an entire personalized preparation operating system.

---

## ⚡ Core Philosophy: Minimum User Input Principle

The user specifies only:
1. **Exam Name** (e.g. *PWNSAT*, *UP Board Class 10*, *JEE Main*, *NEET UG*, *Digital SAT*, or any custom exam)
2. **Exam Date** (e.g. *20 October 2026*, *20 February 2027*)
*(Optional: Target Score & Student Name)*

The autonomous engine handles everything else:
- Discovers the conducting authority, pattern, duration, marking rules (+4 / -1 or board schemes), and negative penalties.
- Researches the official syllabus down to granular nodes: **EXAM → SECTION → SUBJECT → CHAPTER → TOPIC → CONCEPT**.
- Employs **Source Verification** tagging every discovery as `OFFICIAL`, `VERIFIED SECONDARY`, `UNVERIFIED`, or `AI INFERENCE`.
- Conducts an adaptive initial interview and short baseline diagnostic test.
- Answers in real-time: **"WHAT SHOULD I DO NOW?"** with mathematical reason, duration, and target outcome.
- Continuously adapts with the **Countdown Strategy Engine** (Early Foundation, Mid Phase, Late Intensive, Final 14 Days, Final 7 Days, and Final 24 Hours).
- Evaluates **Plan Feasibility** against realistic historical study capacity.
- Embeds **The Error Doctor** to classify mistakes (Calculation, Formula, Concept, Careless, Misread, Time Pressure) and schedule targeted repair tasks.
- Integrates **Focus Mode & App Shielding** using Android Usage Access to track interruptions and restrict distracting apps.

---

## 🏛️ Architecture Overview

```
com.example
├── data
│   ├── api
│   │   ├── ApiModels.kt              // Moshi-compatible JSON payloads for Gemini API
│   │   └── GeminiApiClient.kt        // Multi-model Gemini client (Flash, Pro Preview, Flash Lite)
│   ├── db
│   │   ├── ExamEntities.kt           // Room persistence entities (Profiles, Chapters, Revisions, Errors)
│   │   ├── ExamDao.kt                // Reactive DAOs with Coroutines & StateFlow
│   │   └── ExamOsDatabase.kt         // Thread-safe Room Database singleton
│   ├── model
│   │   └── ExamModels.kt             // Domain enums (ExamPhase, TopicStatus, ErrorType, AiMode)
│   └── repository
│       ├── ExamRepository.kt         // Curricular graph & readiness scoring
│       ├── StudyPlannerRepository.kt // Deterministic daily tasks & replanning
│       ├── StudySessionRepository.kt // Active session logging & time analytics
│       ├── FocusRepository.kt        // Distraction shielding & app block toggles
│       ├── RevisionRepository.kt     // Spaced repetition queue (Day 0, 1, 3, 7, 14, 30)
│       ├── ErrorRepository.kt        // Error Intelligence & category distribution
│       └── TestRepository.kt         // Diagnostic tests, grading, and explanations
├── domain
│   ├── ExamResearcherEngine.kt       // Autonomous onboarding research pipeline
│   ├── CountdownStrategyEngine.kt    // Timeline compression & phase transition advisor
│   ├── PlanFeasibilityEngine.kt      // Mathematical capacity vs workload calculator
│   ├── NextActionEngine.kt           // "WHAT SHOULD I DO NOW?" decision algorithm
│   └── BehaviorLearningEngine.kt     // Learns true capacity from historical sessions
└── ui
    ├── theme                         // Obsidian & Slate Command Center M3 theme
    ├── components                    // WhatShouldIDoNowCard, SourceBadge, TimerOverlay, Gauge
    ├── screens                       // Onboarding, Dashboard, Syllabus, Focus, Tests, Errors, AI OS, Settings
    └── viewmodel                     // Unified reactive StateFlow ViewModel
```

---

## 🛠️ Build & Installation Instructions

### Prerequisites
- Android Studio Ladybug / Meerkat or command-line Gradle 8.13+
- Android SDK 36 (minSdk 24)
- JDK 17 or 21

### Local Debug Build
```bash
# Clone the repository
git clone https://github.com/your-username/exam-os.git
cd exam-os

# Run compilation & local unit tests
gradle :app:testDebugUnitTest

# Assemble Debug APK
gradle :app:assembleDebug
```
The generated APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 🔑 AI Configuration & Secrets

EXAM OS supports **Google Gemini API** (`gemini-3.5-flash`, `gemini-3.1-pro-preview`, and `gemini-3.1-flash-lite-preview`).

1. **AI Studio Secrets Injection**: In AI Studio, add `GEMINI_API_KEY` to your secrets panel.
2. **In-App Key Configuration**: Users can enter their custom API key in the **Settings** screen, which is encrypted locally in Android private app storage.
3. **Offline Fallback**: When offline or if an API key is unconfigured, all deterministic engines (Planner, Spaced Revision, Timer, Analytics, Error Doctor, Diagnostics) operate with 100% offline autonomy.

---

## 🧪 Unit Testing

Unit tests for all deterministic mathematical engines are located at:
`app/src/test/java/com/example/ExamOsDomainTest.kt`

Execute tests via:
```bash
gradle :app:testDebugUnitTest
```
Tests verify:
- Countdown phase transition logic
- Plan mathematical feasibility & deficit calculations
- Next action priority hierarchy (Spaced revision > today's critical tasks > weak chapter repair)
- Behavior learning engine capacity & focus efficiency calculations
