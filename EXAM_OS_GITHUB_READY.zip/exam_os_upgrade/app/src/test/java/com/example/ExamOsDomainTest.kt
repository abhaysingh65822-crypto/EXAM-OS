package com.example

import com.example.data.db.DailyPlanTaskEntity
import com.example.data.db.ExamChapterEntity
import com.example.data.db.ExamProfileEntity
import com.example.data.db.ExamTopicEntity
import com.example.data.db.FocusSessionEntity
import com.example.data.db.RevisionItemEntity
import com.example.data.db.StudySessionEntity
import com.example.data.model.ExamPhase
import com.example.data.model.TopicStatus
import com.example.domain.BehaviorLearningEngine
import com.example.domain.CountdownStrategyEngine
import com.example.domain.NextActionEngine
import com.example.domain.PlanFeasibilityEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExamOsDomainTest {

    @Test
    fun testCountdownPhases() {
        assertEquals(ExamPhase.FINAL_24_HOURS, CountdownStrategyEngine.determinePhase(0))
        assertEquals(ExamPhase.FINAL_24_HOURS, CountdownStrategyEngine.determinePhase(1))
        assertEquals(ExamPhase.FINAL_7_DAYS, CountdownStrategyEngine.determinePhase(5))
        assertEquals(ExamPhase.FINAL_14_DAYS, CountdownStrategyEngine.determinePhase(12))
        assertEquals(ExamPhase.LATE_INTENSIVE, CountdownStrategyEngine.determinePhase(30))
        assertEquals(ExamPhase.MID_PREPARATION, CountdownStrategyEngine.determinePhase(80))
        assertEquals(ExamPhase.EARLY_FOUNDATION, CountdownStrategyEngine.determinePhase(150))
    }

    @Test
    fun testPlanFeasibilityCalculation() {
        // 20 days remaining, required 3000 mins (50 hours), capacity 180 min/day (3 hrs/day => 60 hrs available) -> Feasible
        val feasibleReport = PlanFeasibilityEngine.evaluateFeasibility(
            daysRemaining = 20,
            totalRequiredMinutes = 3000,
            historicalDailyAverageMinutes = 180
        )
        assertTrue(feasibleReport.isFeasible)
        assertEquals(0f, feasibleReport.deficitHours, 0.01f)

        // 10 days remaining, required 6000 mins (100 hours), capacity 180 min/day (30 hrs available) -> Deficit of 70 hours
        val deficitReport = PlanFeasibilityEngine.evaluateFeasibility(
            daysRemaining = 10,
            totalRequiredMinutes = 6000,
            historicalDailyAverageMinutes = 180
        )
        assertFalse(deficitReport.isFeasible)
        assertTrue(deficitReport.deficitHours > 60f)
        assertTrue(deficitReport.recommendations.isNotEmpty())
    }

    @Test
    fun testNextActionPrecedence() {
        val profile = ExamProfileEntity(
            examName = "PWNSAT",
            targetExamDateEpochMs = System.currentTimeMillis() + (20L * 24 * 60 * 60 * 1000)
        )

        val overdueRevision = RevisionItemEntity(
            examId = 1,
            topicId = 10,
            topicName = "Ohm's Law & Circuits",
            subjectName = "Physics",
            chapterName = "Electricity",
            currentIntervalDay = 3,
            nextRevisionEpochMs = System.currentTimeMillis() - 1000,
            retentionScore = 65
        )

        val pendingTask = DailyPlanTaskEntity(
            examId = 1,
            dateString = "2026-10-03",
            priorityOrder = 1,
            subjectName = "Chemistry",
            chapterName = "Chemical Bonding",
            topicName = "Dipole Moments",
            taskType = "THEORY",
            durationMinutes = 40,
            reason = "High exam weightage",
            expectedOutcome = "Complete derivations"
        )

        // Case 1: Overdue revision present -> Must take top priority
        val recWithRevision = NextActionEngine.computeNextAction(
            profile = profile,
            pendingTasks = listOf(pendingTask),
            overdueRevisions = listOf(overdueRevision),
            chapters = emptyList(),
            topics = emptyList()
        )
        assertEquals("SPACED_REVISION", recWithRevision.taskType)
        assertTrue(recWithRevision.title.contains("Ohm's Law"))

        // Case 2: No overdue revisions -> Pending daily task takes precedence
        val recWithTask = NextActionEngine.computeNextAction(
            profile = profile,
            pendingTasks = listOf(pendingTask),
            overdueRevisions = emptyList(),
            chapters = emptyList(),
            topics = emptyList()
        )
        assertEquals("THEORY", recWithTask.taskType)
        assertEquals("Chemistry", recWithTask.subject)
    }

    @Test
    fun testBehaviorLearningEngine() {
        val now = System.currentTimeMillis()
        val sessions = listOf(
            StudySessionEntity(
                examId = 1,
                subjectName = "Physics",
                chapterName = "Electricity",
                topicName = "Ohm's Law",
                taskType = "PRACTICE",
                plannedDurationMinutes = 60,
                actualDurationMinutes = 60,
                focusedDurationMinutes = 48,
                timestampEpochMs = now
            ),
            StudySessionEntity(
                examId = 1,
                subjectName = "Math",
                chapterName = "Calculus",
                topicName = "Integration",
                taskType = "PYQ",
                plannedDurationMinutes = 60,
                actualDurationMinutes = 60,
                focusedDurationMinutes = 42,
                timestampEpochMs = now
            )
        )

        val focusSessions = listOf(
            FocusSessionEntity(
                examId = 1,
                focusMode = "Study Focus",
                plannedMinutes = 60,
                focusedMinutes = 48,
                efficiencyPct = 80,
                timestampEpochMs = now
            )
        )

        val (capacity, efficiency) = BehaviorLearningEngine.calculateCapacityAndEfficiency(sessions, focusSessions)
        assertTrue(capacity > 0)
        assertEquals(75, efficiency) // (48 + 42) / 120 = 90 / 120 = 75%
    }
}
