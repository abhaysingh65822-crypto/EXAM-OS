package com.example.ui.screens.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun AiStudyOsScreen(viewModel: ExamOsViewModel, onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val reply by viewModel.aiReply.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val context = LocalContext.current
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                if (bytes.isNotEmpty()) viewModel.analyzeImage(bytes, context.contentResolver.getType(uri) ?: "image/jpeg")
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("AI STUDY OS", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onBack) { Text("Back") }
        }
        Text("Try: ‘Maths weak hai, quadratic nahi aata aur kal 2 ghante hain’ or ‘50 questions banao’.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        reply?.let { LazyColumn(Modifier.weight(1f).fillMaxWidth()) { item { ElevatedCard { Text(it, Modifier.padding(14.dp)) } } } } ?: Spacer(Modifier.weight(1f))
        OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Tell Exam OS what to do…") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy && input.isNotBlank(), onClick = { viewModel.sendAiMessage(input); input = "" }, modifier = Modifier.weight(1f)) { Text(if (busy) "Working…" else "Execute with AI") }
            OutlinedButton(enabled = !busy, onClick = { imagePicker.launch("image/*") }) { Text("📷 Image") }
        }
    }
}
