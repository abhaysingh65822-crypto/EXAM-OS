package com.example.domain.ai

import com.example.data.model.TopicStatus
import com.example.data.model.UserControlMode
import java.util.regex.Pattern

object AiIntentClassifier {

    fun classify(message: String): List<ClassifiedIntent> {
        val trimmed = message.trim().lowercase()
        val results = mutableListOf<ClassifiedIntent>()

        // 1. EXAM SETUP / SWITCH INTENT (Explicit intent to change/setup exam in the app)
        val isExplicitSetupAction = (trimmed.contains("setup") || trimmed.contains("set up") ||
                trimmed.contains("switch to") || trimmed.contains("switch my exam") ||
                trimmed.contains("change to") || trimmed.contains("change exam") ||
                trimmed.contains("set my exam") || trimmed.contains("configure exam") ||
                trimmed.contains("select exam") || trimmed.contains("choose exam") ||
                (trimmed.startsWith("switch") && (trimmed.contains("board") || trimmed.contains("jee") || trimmed.contains("neet"))))

        if (isExplicitSetupAction) {
            val entities = mutableMapOf<String, String>()
            when {
                trimmed.contains("up board") || trimmed.contains("upmsp") || trimmed.contains("uttar pradesh") -> {
                    entities["exam"] = "UP Board Class 10 High School 2027"
                }
                trimmed.contains("cbse") -> {
                    entities["exam"] = "CBSE Class 10 Board 2027"
                }
                trimmed.contains("icse") || trimmed.contains("cisce") -> {
                    entities["exam"] = "ICSE Class 10 Board 2027"
                }
                trimmed.contains("jee") -> {
                    entities["exam"] = "JEE Main 2027"
                }
                trimmed.contains("neet") -> {
                    entities["exam"] = "NEET UG 2027"
                }
                trimmed.contains("pwnsat") -> {
                    entities["exam"] = "PWNSAT 2026"
                }
                trimmed.contains("sat") -> {
                    entities["exam"] = "Digital SAT 2026"
                }
                else -> {
                    val cleanExam = message.replace(Regex("(?i)(setup|set up|switch to|switch my exam to|change exam to|change to|set my exam to)"), "").trim()
                    entities["exam"] = if (cleanExam.isNotBlank()) cleanExam else "CBSE Class 10 Board 2027"
                }
            }
            results.add(ClassifiedIntent(StudentIntent.SETUP_EXAM, IntentConfidence.HIGH, entities))
            return results
        }

        // 2. SWITCH OPERATING / CONTROL MODE
        if (trimmed.contains("auto pilot") || trimmed.contains("autonomous mode") ||
            trimmed.contains("co pilot") || trimmed.contains("copilot") ||
            trimmed.contains("manual mode") || trimmed.contains("student control") ||
            trimmed.contains("switch mode")
        ) {
            val mode = when {
                trimmed.contains("manual") || trimmed.contains("student") -> UserControlMode.MANUAL.name
                trimmed.contains("suggest") || trimmed.contains("copilot") || trimmed.contains("co pilot") -> UserControlMode.SUGGEST.name
                else -> UserControlMode.AUTO.name
            }
            results.add(ClassifiedIntent(StudentIntent.SWITCH_CONTROL_MODE, IntentConfidence.HIGH, mapOf("mode" to mode)))
            return results
        }

        // 3. STOP STUDY FOCUS SESSION
        if (trimmed.startsWith("stop session") || trimmed.startsWith("end session") ||
            trimmed.startsWith("finish session") || trimmed.startsWith("stop timer") ||
            trimmed.contains("session khatam") || trimmed.contains("padhai band")
        ) {
            results.add(ClassifiedIntent(StudentIntent.STOP_SESSION, IntentConfidence.HIGH))
            return results
        }

        // 4. START STUDY FOCUS SESSION
        if (trimmed.startsWith("start session") || trimmed.startsWith("start study") ||
            trimmed.startsWith("start focus") || trimmed.startsWith("start timer") ||
            trimmed.contains("focus session shuru") || trimmed.contains("padhai shuru")
        ) {
            val entities = mutableMapOf<String, String>()
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            extractChapterEntity(trimmed)?.let { entities["chapter"] = it }
            val minMatcher = Pattern.compile("(\\d+)\\s*(min|minute|m)").matcher(trimmed)
            if (minMatcher.find()) {
                entities["duration"] = minMatcher.group(1) ?: "30"
            }
            results.add(ClassifiedIntent(StudentIntent.START_SESSION, IntentConfidence.HIGH, entities))
            return results
        }

        // 5. ADD / DELETE SUBJECT
        if (trimmed.contains("add subject") || trimmed.contains("nayi subject") || trimmed.contains("include subject")) {
            val cleanSubject = message.replace(Regex("(?i)(add subject|nayi subject|include subject|subject)"), "").trim().trim(':', '-', ' ')
            val subjectName = if (cleanSubject.isNotBlank()) cleanSubject else "Computer Science"
            results.add(ClassifiedIntent(StudentIntent.ADD_SUBJECT, IntentConfidence.HIGH, mapOf("subject" to subjectName)))
            return results
        }

        if (trimmed.contains("delete subject") || trimmed.contains("remove subject") || trimmed.contains("hatao subject")) {
            val cleanSubject = message.replace(Regex("(?i)(delete subject|remove subject|hatao subject|subject)"), "").trim().trim(':', '-', ' ')
            val subjectName = extractSubjectEntity(trimmed) ?: if (cleanSubject.isNotBlank()) cleanSubject else "General"
            results.add(ClassifiedIntent(StudentIntent.DELETE_SUBJECT, IntentConfidence.HIGH, mapOf("subject" to subjectName)))
            return results
        }

        // 6. ADD / DELETE CHAPTER
        if (trimmed.contains("add chapter") || trimmed.contains("naya chapter") || trimmed.contains("include chapter")) {
            val entities = mutableMapOf<String, String>()
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            val cleanChapter = message.replace(Regex("(?i)(add chapter|naya chapter|include chapter|chapter|to|in)"), "").trim().trim(':', '-', ' ')
            entities["chapter"] = if (cleanChapter.isNotBlank()) cleanChapter else "New Chapter"
            results.add(ClassifiedIntent(StudentIntent.ADD_CHAPTER, IntentConfidence.HIGH, entities))
            return results
        }

        if (trimmed.contains("delete chapter") || trimmed.contains("remove chapter") || trimmed.contains("hatao chapter")) {
            val entities = mutableMapOf<String, String>()
            val chap = extractChapterEntity(trimmed) ?: message.replace(Regex("(?i)(delete chapter|remove chapter|hatao chapter|chapter)"), "").trim()
            entities["chapter"] = chap
            results.add(ClassifiedIntent(StudentIntent.DELETE_CHAPTER, IntentConfidence.HIGH, entities))
            return results
        }

        // 7. RESET ROADMAP
        if (trimmed.contains("reset roadmap") || trimmed.contains("clear roadmap") || trimmed.contains("roadmap reset")) {
            results.add(ClassifiedIntent(StudentIntent.RESET_ROADMAP, IntentConfidence.HIGH))
            return results
        }

        // 8. UPDATE EXAM TARGET SCORE / TARGET DATE / DAILY TARGET
        if (trimmed.contains("target score") || trimmed.contains("target marks") ||
            (trimmed.contains("set target") && (trimmed.contains("%") || trimmed.contains("percent"))) ||
            trimmed.contains("change exam date") || trimmed.contains("set daily target")
        ) {
            val entities = mutableMapOf<String, String>()
            val scoreMatcher = Pattern.compile("(\\d+%|\\d+\\s*percent|\\d+\\+)").matcher(trimmed)
            if (scoreMatcher.find()) {
                entities["score"] = scoreMatcher.group(1) ?: "95%+"
            }
            val hourMatcher = Pattern.compile("(\\d+)\\s*(hours?|hrs?|ghante)").matcher(trimmed)
            if (hourMatcher.find()) {
                entities["hours"] = hourMatcher.group(1) ?: "4"
            }
            results.add(ClassifiedIntent(StudentIntent.UPDATE_EXAM_SETTINGS, IntentConfidence.HIGH, entities))
            return results
        }

        // 9. LOCK / UNLOCK ROADMAP DAY
        if (trimmed.contains("lock day") || trimmed.contains("unlock day") || trimmed.contains("lock today") || trimmed.contains("unlock today")) {
            val dayMatcher = Pattern.compile("day\\s*(\\d+)").matcher(trimmed)
            val dayNum = if (dayMatcher.find()) dayMatcher.group(1)?.toIntOrNull() ?: 1 else 1
            val action = if (trimmed.contains("unlock")) "unlock" else "lock"
            results.add(
                ClassifiedIntent(
                    StudentIntent.LOCK_DAY,
                    IntentConfidence.HIGH,
                    mapOf("day" to dayNum.toString(), "action" to action)
                )
            )
            return results
        }

        // 10. COMPLETE ROADMAP DAY / TASKS
        if (trimmed.contains("complete day") || (trimmed.contains("mark day") && trimmed.contains("done")) ||
            trimmed.contains("mark today done") || trimmed.contains("today's task complete") ||
            trimmed.contains("finished today's plan") || trimmed.contains("complete today")
        ) {
            val dayMatcher = Pattern.compile("day\\s*(\\d+)").matcher(trimmed)
            val dayNum = if (dayMatcher.find()) dayMatcher.group(1)?.toIntOrNull() ?: 1 else 1
            results.add(
                ClassifiedIntent(
                    StudentIntent.COMPLETE_DAY,
                    IntentConfidence.HIGH,
                    mapOf("day" to dayNum.toString())
                )
            )
            return results
        }

        // 11. REBUILD ROADMAP / MAX POWER (e.g. "rebuild roadmap for 366 days", "max power", "90 days", "aggressive", "missed yesterday")
        if (trimmed.contains("rebuild roadmap") || trimmed.contains("366 days") || trimmed.contains("366 day") ||
            trimmed.contains("max power") || trimmed.contains("replan") || trimmed.contains("shift my plan") ||
            trimmed.contains("missed yesterday") || trimmed.contains("kal nahi padha") ||
            trimmed.contains("aggressive") || trimmed.contains("fast track") ||
            (trimmed.contains("roadmap") && (trimmed.contains("change") || trimmed.contains("update") || trimmed.contains("generate")))
        ) {
            val entities = mutableMapOf<String, String>()
            val daysMatcher = Pattern.compile("(\\d+)\\s*days?").matcher(trimmed)
            if (daysMatcher.find()) {
                entities["days"] = daysMatcher.group(1) ?: "366"
            } else if (trimmed.contains("366") || trimmed.contains("max power")) {
                entities["days"] = "366"
            } else if (trimmed.contains("180")) {
                entities["days"] = "180"
            } else if (trimmed.contains("90")) {
                entities["days"] = "90"
            } else if (trimmed.contains("30")) {
                entities["days"] = "30"
            }
            results.add(ClassifiedIntent(StudentIntent.REBUILD_ROADMAP, IntentConfidence.HIGH, entities))
            return results
        }

        // 12. WHAT SHOULD I DO NOW?
        if (trimmed.contains("ab kya padhu") || trimmed.contains("what should i do") ||
            trimmed.contains("what to study") || trimmed.contains("kya padhna chahiye") ||
            trimmed.contains("aaj kya padhu") || trimmed.contains("next task")
        ) {
            results.add(ClassifiedIntent(StudentIntent.WHAT_SHOULD_I_DO_NOW, IntentConfidence.HIGH))
            return results
        }

        // 13. GENERATE QUESTIONS / TESTS (e.g. "50 questions banao", "30 questions do", "give me 50 questions")
        val qPattern = Pattern.compile("(\\d+)\\s*(questions|prashn|sawal|q)")
        val qMatcher = qPattern.matcher(trimmed)
        if (qMatcher.find() || trimmed.contains("question set") || trimmed.contains("practice questions")) {
            val count = if (qMatcher.find(0)) qMatcher.group(1)?.toIntOrNull() ?: 50 else 50
            val entities = mutableMapOf("count" to count.toString())
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            extractChapterEntity(trimmed)?.let { entities["chapter"] = it }
            results.add(ClassifiedIntent(StudentIntent.GENERATE_QUESTIONS, IntentConfidence.HIGH, entities))
            return results
        }

        // 14. CREATE MOCK TEST
        if (trimmed.contains("mock test") || trimmed.contains("full mock") || trimmed.contains("test banao") ||
            trimmed.contains("create a test") || trimmed.contains("make a test") || trimmed.contains("test for me")
        ) {
            val entities = mutableMapOf<String, String>()
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            results.add(ClassifiedIntent(StudentIntent.CREATE_MOCK, IntentConfidence.HIGH, entities))
            return results
        }

        // 15. UPDATE PROGRESS (e.g. "Physics complete hai", "Quadratic done", "Finished Biology")
        if (trimmed.contains("complete") || trimmed.contains("done") || trimmed.contains("khatam") ||
            trimmed.contains("padh liya") || trimmed.contains("finished")
        ) {
            val entities = mutableMapOf<String, String>()
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            extractChapterEntity(trimmed)?.let { entities["chapter"] = it }
            entities["status"] = TopicStatus.MASTERED.name
            results.add(ClassifiedIntent(StudentIntent.UPDATE_PROGRESS, IntentConfidence.HIGH, entities))
            return results
        }

        // 16. REPORT WEAKNESS
        if (trimmed.contains("weak") || trimmed.contains("kamzor") || trimmed.contains("difficult") ||
            trimmed.contains("samajh nahi") || trimmed.contains("problem aa rahi") || trimmed.contains("doubt") ||
            trimmed.contains("struggling")
        ) {
            val entities = mutableMapOf<String, String>()
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            extractChapterEntity(trimmed)?.let { entities["chapter"] = it }
            results.add(ClassifiedIntent(StudentIntent.REPORT_WEAKNESS, IntentConfidence.HIGH, entities))
            return results
        }

        // 17. REPORT STRENGTH
        if (trimmed.contains("strong") || trimmed.contains("confident") || trimmed.contains("achha hai") ||
            trimmed.contains("command hai") || trimmed.contains("best hai")
        ) {
            val entities = mutableMapOf<String, String>()
            extractSubjectEntity(trimmed)?.let { entities["subject"] = it }
            extractChapterEntity(trimmed)?.let { entities["chapter"] = it }
            results.add(ClassifiedIntent(StudentIntent.REPORT_STRENGTH, IntentConfidence.HIGH, entities))
            return results
        }

        // 18. CHANGE AVAILABILITY / STUDY TIME & SCHOOL HOURS
        val hourPattern = Pattern.compile("(\\d+)\\s*(hours|hour|ghante|ghanta|hr|hrs)")
        val hourMatcher = hourPattern.matcher(trimmed)
        if (hourMatcher.find()) {
            val hours = hourMatcher.group(1)?.toFloatOrNull() ?: 3.0f
            val entities = mutableMapOf("hours" to hours.toString())
            if (trimmed.contains("kal") || trimmed.contains("tomorrow")) {
                entities["scope"] = "tomorrow"
            } else if (trimmed.contains("sunday")) {
                entities["scope"] = "sunday"
            } else {
                entities["scope"] = "daily"
            }
            results.add(ClassifiedIntent(StudentIntent.CHANGE_AVAILABILITY, IntentConfidence.HIGH, entities))
            return results
        }

        // 19. WHAT-IF SIMULATION
        if (trimmed.contains("what if") || trimmed.contains("agar main") || trimmed.contains("kya hoga agar")) {
            val entities = mutableMapOf("query" to message)
            results.add(ClassifiedIntent(StudentIntent.WHAT_IF_QUERY, IntentConfidence.HIGH, entities))
            return results
        }

        // 20. SYNC SYLLABUS
        if (trimmed.contains("sync syllabus") || trimmed.contains("syllabus update") || trimmed.contains("cbse syllabus update")) {
            results.add(ClassifiedIntent(StudentIntent.SYNC_SYLLABUS, IntentConfidence.HIGH))
            return results
        }

        // 21. CLEAR TEST HISTORY
        if (trimmed.contains("clear tests") || trimmed.contains("reset tests") || trimmed.contains("clear question bank")) {
            results.add(ClassifiedIntent(StudentIntent.CLEAR_TEST_HISTORY, IntentConfidence.HIGH))
            return results
        }

        // Fallback: General Chat / Syllabus inquiry / Doubt resolution / Educational queries
        results.add(ClassifiedIntent(StudentIntent.GENERAL_CHAT, IntentConfidence.HIGH))
        return results
    }

    fun extractSubjectEntity(text: String): String? {
        val t = text.lowercase()
        return when {
            t.contains("math") || t.contains("ganit") -> "Mathematics"
            t.contains("physic") || t.contains("bhautik") -> "Physics"
            t.contains("chem") || t.contains("rasayan") -> "Chemistry"
            t.contains("bio") || t.contains("jeev") -> "Biology"
            t.contains("science") || t.contains("vigyan") -> "Science"
            t.contains("social") || t.contains("samajik") -> "Social Science"
            t.contains("english") -> "English"
            t.contains("hindi") -> "Hindi"
            t.contains("computer") || t.contains("cs") || t.contains("it") -> "Computer Science"
            else -> null
        }
    }

    fun extractChapterEntity(text: String): String? {
        val t = text.lowercase()
        return when {
            t.contains("quadratic") -> "Quadratic Equations"
            t.contains("real number") -> "Real Numbers"
            t.contains("triangle") -> "Triangles"
            t.contains("trigonometr") -> "Trigonometry"
            t.contains("electric") -> "Electricity & Circuit Laws"
            t.contains("light") || t.contains("optics") -> "Light: Reflection & Refraction"
            t.contains("chemical reaction") -> "Chemical Reactions & Equations"
            t.contains("acid") || t.contains("base") -> "Acids, Bases & Salts"
            t.contains("life process") -> "Life Processes: Nutrition & Respiration"
            t.contains("mechanic") || t.contains("kinematic") -> "Kinematics & Mechanics"
            t.contains("integration") -> "Definite Integration & Areas"
            t.contains("vector") -> "Vectors & 3D Geometry"
            t.contains("bonding") -> "Chemical Bonding"
            t.contains("genetics") -> "Heredity & Evolution"
            t.contains("circle") -> "Circles"
            t.contains("coordinate") -> "Coordinate Geometry"
            t.contains("surface area") -> "Surface Areas & Volumes"
            t.contains("carbon") -> "Carbon & its Compounds"
            t.contains("metal") -> "Metals & Non-Metals"
            t.contains("reproduction") -> "How do Organisms Reproduce"
            else -> null
        }
    }
}
