package com.example.data.model

enum class ExamPhase(val displayName: String, val description: String) {
    EARLY_FOUNDATION("Early Phase", "Concept building, theory & foundation practice"),
    MID_PREPARATION("Mid Phase", "Targeted practice, PYQs, spaced revision & unit tests"),
    LATE_INTENSIVE("Late Phase", "High-yield PYQs, full mock tests & weakness repair"),
    FINAL_14_DAYS("Final 14 Days", "High-yield rapid recall, error repair & mock simulation"),
    FINAL_7_DAYS("Final 7 Days", "Previous mistakes review, formula recall & strictly no heavy new topics"),
    FINAL_24_HOURS("Final 24 Hours", "Light recall, exam instructions, required materials & sleep protection")
}

enum class TopicStatus(val displayName: String) {
    NOT_STARTED("Not Started"),
    LEARNING("Learning"),
    PRACTICING("Practicing"),
    PYQ("PYQ Solving"),
    TESTED("Tested"),
    WEAK("Needs Repair"),
    NEEDS_REVISION("Needs Revision"),
    STRONG("Strong"),
    MASTERED("Mastered")
}

enum class VerificationStatus(val displayName: String, val badgeColorHex: String) {
    OFFICIAL("Official Source", "#10B981"),
    VERIFIED_SECONDARY("Verified Secondary", "#3B82F6"),
    UNVERIFIED("Unverified", "#F59E0B"),
    AI_INFERENCE("AI Inference", "#A855F7")
}

enum class ErrorType(val label: String, val hint: String) {
    CONCEPT("Concept Gap", "Fundamental misunderstanding of core principle"),
    FORMULA("Formula Error", "Incorrect or misapplied mathematical/physical formula"),
    CALCULATION("Calculation Slip", "Arithmetic or algebraic sign mistake"),
    MEMORY("Memory Lapse", "Forgot rule, constant, exception or reaction"),
    CARELESS("Careless Error", "Rushed execution or missed obvious clue"),
    MISREAD("Misread Question", "Failed to see 'NOT', 'EXCEPT', or wrong units"),
    LOGIC("Logic Flaw", "Valid steps but flawed deduction sequence"),
    VISUALIZATION("Visualization", "Misinterpreted graph, diagram or 3D geometry"),
    TIME_PRESSURE("Time Pressure", "Panicked under clock and committed error"),
    GUESS("Blind Guess", "Gambled on option without sound derivation")
}

enum class UserControlMode(val displayName: String) {
    AUTO("Autonomous OS"),
    SUGGEST("AI Suggestion Mode"),
    MANUAL("Manual Override")
}

enum class AiMode(val title: String, val icon: String, val description: String) {
    EXAM_RESEARCHER("Exam Researcher", "search", "Autonomous discovery of official syllabus & pattern"),
    STUDY_PLANNER("Study Planner", "calendar", "Deterministic roadmap & time architect"),
    DAILY_COACH("Daily Coach", "alarm", "Morning briefing & strategic daily direction"),
    TEACHER("AI Teacher", "school", "Multi-level conceptual breakdown & analogies"),
    DOUBT_SOLVER("Doubt Solver", "help", "Step-by-step resolution of tricky questions"),
    EXAMINER("AI Examiner", "quiz", "Adaptive diagnostic & mock exam generation"),
    QUIZ_MASTER("Quiz Master", "timer", "Rapid-fire recall quiz for immediate retention"),
    PYQ_ANALYST("PYQ Analyst", "analytics", "Past 10 years weightage & pattern trends"),
    ERROR_DOCTOR("Error Doctor", "healing", "Identifies repeated mistakes & creates repair tasks"),
    REVISION_COACH("Revision Coach", "repeat", "Optimized spaced repetition intervals"),
    BACKLOG_MANAGER("Backlog Manager", "assignment_late", "Intelligent recovery without student burnout"),
    STRATEGY_COACH("Strategy Coach", "psychology", "Exam-taking tactics, section pacing & negative marking control"),
    ACTIVE_RECALL("Active Recall", "record_voice_over", "Explain concepts without notes to check gaps"),
    COUNTDOWN_COACH("Countdown Coach", "hourglass_top", "Timeline compression & phase transition advisor"),
    WAR_ROOM_ADVISOR("War Room Advisor", "military_tech", "High-risk topic mitigation & target score trajectory")
}

data class NextActionRecommendation(
    val title: String,
    val subject: String,
    val chapter: String,
    val topic: String,
    val taskType: String,
    val durationMinutes: Int,
    val urgencyReason: String,
    val expectedOutcome: String,
    val priorityRank: Int = 1
)

data class FeasibilityReport(
    val isFeasible: Boolean,
    val requiredTotalHours: Float,
    val availableTotalHours: Float,
    val realisticDailyStudyHours: Float,
    val deficitHours: Float,
    val bufferPercentage: Float,
    val recommendations: List<String>
)

data class ResearchProgressStep(
    val stepIndex: Int,
    val stepTitle: String,
    val detail: String,
    val isCompleted: Boolean = false,
    val isInProgress: Boolean = false
)
