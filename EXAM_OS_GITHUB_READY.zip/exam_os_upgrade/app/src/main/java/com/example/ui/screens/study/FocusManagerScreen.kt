package com.example.ui.screens.study

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun FocusManagerScreen(viewModel: ExamOsViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Focus Mode", style = MaterialTheme.typography.headlineMedium)
        Text("Focus sessions are logged locally so future roadmap decisions can learn your actual study capacity.")
        Button(onClick = { viewModel.sendAiMessage("Start a 45 minute focus session for my highest priority task") }) { Text("Start via AI") }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
