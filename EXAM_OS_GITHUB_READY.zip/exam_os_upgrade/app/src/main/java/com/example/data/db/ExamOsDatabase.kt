package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ExamProfileEntity::class,
        ExamSubjectEntity::class,
        ExamChapterEntity::class,
        ExamTopicEntity::class,
        StudySessionEntity::class,
        DailyPlanTaskEntity::class,
        RevisionItemEntity::class,
        ErrorLogEntity::class,
        TestModelEntity::class,
        TestQuestionEntity::class,
        BlockedAppEntity::class,
        FocusSessionEntity::class,
        AiAuditLogEntity::class,
        QuestionBankEntity::class,
        RoadmapPlanVersionEntity::class,
        StudentAvailabilityEntity::class,
        AiActionAuditEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class ExamOsDatabase : RoomDatabase() {
    abstract fun examDao(): ExamDao

    companion object {
        @Volatile
        private var INSTANCE: ExamOsDatabase? = null

        fun getDatabase(context: Context): ExamOsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ExamOsDatabase::class.java,
                    "exam_os_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
