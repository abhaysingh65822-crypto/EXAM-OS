package com.example.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun SettingsScreen(viewModel: ExamOsViewModel, onBack: () -> Unit, onResetSetup: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text("AI provider: Google Search AI default; Gemini remains optional when a key is configured.")
        Text("Core roadmap, progress, scores and dates remain deterministic and stored locally.")
        OutlinedButton(onClick = onResetSetup) { Text("Start a new exam profile") }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
