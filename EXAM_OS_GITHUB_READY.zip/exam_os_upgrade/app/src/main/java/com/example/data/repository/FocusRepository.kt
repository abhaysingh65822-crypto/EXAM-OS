package com.example.data.repository

import com.example.data.db.BlockedAppEntity
import com.example.data.db.ExamDao
import com.example.data.db.FocusSessionEntity
import kotlinx.coroutines.flow.Flow

class FocusRepository(private val dao: ExamDao) {

    val blockedAppsFlow: Flow<List<BlockedAppEntity>> = dao.getBlockedAppsFlow()
    val focusSessionsFlow: Flow<List<FocusSessionEntity>> = dao.getAllFocusSessionsFlow()

    suspend fun initializeDefaultBlockedAppsIfNeeded() {
        val active = dao.getActiveBlockedApps()
        if (active.isEmpty()) {
            val defaults = listOf(
                BlockedAppEntity("com.google.android.youtube", "YouTube", true, "Video Streaming"),
                BlockedAppEntity("com.instagram.android", "Instagram", true, "Social Media"),
                BlockedAppEntity("com.snapchat.android", "Snapchat", true, "Social Messaging"),
                BlockedAppEntity("com.reddit.frontpage", "Reddit", true, "Community & Forums"),
                BlockedAppEntity("com.twitter.android", "X / Twitter", true, "Social Feed"),
                BlockedAppEntity("com.facebook.katana", "Facebook", true, "Social Network"),
                BlockedAppEntity("com.netflix.mediaclient", "Netflix", true, "Entertainment"),
                BlockedAppEntity("com.dts.freefireth", "Action Games", true, "Gaming")
            )
            dao.insertBlockedApps(defaults)
        }
    }

    suspend fun toggleAppBlock(app: BlockedAppEntity) {
        dao.updateBlockedApp(app.copy(isBlocked = !app.isBlocked))
    }

    suspend fun recordFocusSession(session: FocusSessionEntity): Long {
        return dao.insertFocusSession(session)
    }
}
