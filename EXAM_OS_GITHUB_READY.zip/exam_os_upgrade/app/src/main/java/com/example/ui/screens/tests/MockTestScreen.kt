package com.example.ui.screens.tests

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun MockTestScreen(viewModel: ExamOsViewModel, onBack: () -> Unit) {
    val tests by viewModel.allTests.collectAsState()
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Mock Tests", style = MaterialTheme.typography.headlineMedium); TextButton(onClick = onBack) { Text("Back") } }
        Button(onClick = { viewModel.sendAiMessage("Create a 50 question full mock test from my current syllabus") }) { Text("AI: Create 50-question mock") }
        tests.take(20).forEach { Text("• ${it.title} — ${it.totalQuestions} Q • ${it.durationMinutes} min • score ${it.scoreObtained}") }
    }
}
