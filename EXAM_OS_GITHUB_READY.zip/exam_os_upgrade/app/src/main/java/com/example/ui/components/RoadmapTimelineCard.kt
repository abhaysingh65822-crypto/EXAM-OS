package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.domain.ai.RoadmapDayPlan

@Composable
fun RoadmapTimelineCard(plan: RoadmapDayPlan, onClick: (() -> Unit)? = null) {
    ElevatedCard(onClick = { onClick?.invoke() }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("DAY ${plan.dayNumber} • ${plan.dateString}", style = MaterialTheme.typography.labelLarge)
            Text(plan.taskTitle.ifBlank { plan.chapterName }, style = MaterialTheme.typography.titleMedium)
            Text("${plan.phase} • ${plan.taskType} • ${plan.durationMinutes} min")
            Text(plan.reason, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
