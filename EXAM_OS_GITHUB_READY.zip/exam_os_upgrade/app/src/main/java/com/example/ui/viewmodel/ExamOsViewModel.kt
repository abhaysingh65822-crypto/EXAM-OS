package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiApiClient
import com.example.data.api.GeminiContent
import com.example.data.api.GoogleSearchAiProvider
import com.example.data.db.ExamOsDatabase
import com.example.data.db.ExamProfileEntity
import com.example.data.db.DailyPlanTaskEntity
import com.example.data.db.RoadmapPlanVersionEntity
import com.example.data.repository.ExamRepository
import com.example.data.repository.StudyPlannerRepository
import com.example.domain.ExamResearcherEngine
import com.example.domain.ai.AiToolRegistry
import com.example.domain.ai.AutonomousStudyOsController
import com.example.domain.ai.ControllerAgentResponse
import com.example.domain.roadmap.DynamicRoadmapEngine
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ExamOsViewModel(application: Application) : AndroidViewModel(application) {
    private val db = ExamOsDatabase.getDatabase(application)
    private val dao = db.examDao()
    private val repository = ExamRepository(dao)
    private val planner = StudyPlannerRepository(dao)
    private val researcher = ExamResearcherEngine()
    private val gemini = GeminiApiClient(application)
    private val aiProvider = GoogleSearchAiProvider(gemini)
    private val tools = AiToolRegistry(dao, researcher)
    private val controller = AutonomousStudyOsController(dao, tools, aiProvider)

    val activeProfile: StateFlow<ExamProfileEntity?> = dao.getActiveExamProfileFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val todayTasks: StateFlow<List<DailyPlanTaskEntity>> = planner.getTodayTasksFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val roadmapVersion: StateFlow<RoadmapPlanVersionEntity?> = dao.getLatestRoadmapVersionFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val allTests = dao.getAllTestsFlow().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val weakTopics = dao.getWeakAndRevisionTopics().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _aiReply = MutableStateFlow<String?>(null)
    val aiReply: StateFlow<String?> = _aiReply
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    fun setupExam(examName: String, examDateEpochMs: Long) = viewModelScope.launch {
        _busy.value = true
        try {
            val result = controller.processUserMessage("Set up my exam: $examName. Exam date epoch ms: $examDateEpochMs")
            _aiReply.value = result.conversationalReply
        } finally { _busy.value = false }
    }

    fun sendAiMessage(message: String) = viewModelScope.launch {
        if (message.isBlank()) return@launch
        _busy.value = true
        try {
            val result = controller.processUserMessage(message)
            _aiReply.value = result.conversationalReply
        } catch (t: Throwable) {
            _aiReply.value = "AI action failed safely: ${t.message ?: "unknown error"}. No raw database command was executed."
        } finally { _busy.value = false }
    }

    fun toggleTask(task: DailyPlanTaskEntity) = viewModelScope.launch {
        planner.toggleTaskCompletion(task)
        val profile = repository.getActiveProfile() ?: return@launch
        repository.recalculateReadinessScore()
        planner.generateOrUpdateTodayPlan(profile)
    }

    fun rebuildRoadmap(reason: String = "User requested adaptive rebuild") = viewModelScope.launch {
        _busy.value = true
        try {
            val profile = repository.getActiveProfile() ?: return@launch
            val subjects = dao.getSubjectsList(profile.id)
            val chapters = dao.getAllChapters()
            val availability = dao.getAvailability()
            val currentVersion = dao.getLatestRoadmapVersion()?.versionNumber ?: 0
            val daysLeft = com.example.domain.CountdownStrategyEngine.getDaysRemaining(profile.targetExamDateEpochMs).coerceAtLeast(1).toInt()
            val (plans, version) = DynamicRoadmapEngine.generateDayWiseRoadmap(
                profile, subjects, chapters, availability, reason, currentVersion + 1, daysLeft
            )
            dao.insertRoadmapVersion(version)
            planner.generateOrUpdateTodayPlan(profile)
            _aiReply.value = "Roadmap rebuilt for $daysLeft days. ${plans.count { it.dateString == planner.getTodayDateString() }} task(s) are scheduled today."
        } finally { _busy.value = false }
    }

    fun analyzeImage(bytes: ByteArray, mimeType: String, prompt: String = "Analyze this exam image, solve the question if present, identify topic, mistakes and the best next study action.") = viewModelScope.launch {
        _busy.value = true
        try {
            val result = controller.processUserImage(bytes, mimeType, prompt)
            _aiReply.value = result.conversationalReply
        } catch (t: Throwable) {
            _aiReply.value = "Image analysis failed safely: ${t.message ?: "unknown error"}"
        } finally { _busy.value = false }
    }

    fun clearAiReply() { _aiReply.value = null }
}
