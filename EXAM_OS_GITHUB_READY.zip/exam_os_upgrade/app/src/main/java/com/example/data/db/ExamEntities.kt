package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ErrorType
import com.example.data.model.ExamPhase
import com.example.data.model.TopicStatus
import com.example.data.model.UserControlMode
import com.example.data.model.VerificationStatus

@Entity(tableName = "exam_profiles")
data class ExamProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examName: String,
    val targetExamDateEpochMs: Long,
    val studentName: String = "Student",
    val targetScoreDesc: String = "90%+",
    val conductingBody: String = "National Testing Authority / Official Board",
    val academicYear: String = "2026-2027",
    val durationMinutes: Int = 180,
    val totalMarks: Int = 300,
    val totalQuestions: Int = 75,
    val positiveMarks: Int = 4,
    val negativeMarks: Float = 1.0f,
    val sectionsSummary: String = "Section A (MCQ), Section B (Numerical)",
    val officialWebsiteUrl: String = "https://official.nta.ac.in",
    val sourceName: String = "Official Examination Bulletin",
    val verificationStatus: VerificationStatus = VerificationStatus.OFFICIAL,
    val retrievalDate: String = "October 2026",
    val readinessScore: Int = 0,
    val currentPhase: ExamPhase = ExamPhase.EARLY_FOUNDATION,
    val userMode: UserControlMode = UserControlMode.AUTO,
    val normalStudySlot: String = "Evening (6:00 PM - 10:00 PM)",
    val fixedCommitments: String = "School (8 AM - 2 PM)",
    val historicalDailyAverageMinutes: Int = 180,
    val isSetupCompleted: Boolean = false,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "exam_subjects")
data class ExamSubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val name: String,
    val iconKey: String = "book",
    val weightagePct: Int = 33,
    val estimatedHours: Int = 60,
    val orderIndex: Int = 0
)

@Entity(tableName = "exam_chapters")
data class ExamChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String,
    val importance: String = "HIGH", // HIGH, MEDIUM, LOW
    val masteryScore: Int = 0, // 0 to 100
    val status: TopicStatus = TopicStatus.NOT_STARTED,
    val pyqQuestionCount: Int = 25,
    val orderIndex: Int = 0
)

@Entity(tableName = "exam_topics")
data class ExamTopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chapterId: Long,
    val name: String,
    val subtopicsJson: String = "[]",
    val conceptsJson: String = "[]",
    val estimatedMinutes: Int = 45,
    val status: TopicStatus = TopicStatus.NOT_STARTED,
    val confidenceRating: Int = 0, // 1 to 5
    val understandingScore: Int = 0, // 0 to 100
    val accuracyScore: Int = 0, // 0 to 100
    val retentionScore: Int = 50, // 0 to 100
    val lastStudiedEpochMs: Long = 0,
    val sourceName: String = "Official Syllabus Doc",
    val sourceUrl: String = "",
    val verificationStatus: VerificationStatus = VerificationStatus.OFFICIAL,
    val pyqSolvedCount: Int = 0
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val subjectName: String,
    val chapterName: String,
    val topicName: String,
    val taskType: String, // THEORY, PRACTICE, PYQ, REVISION, MOCK_TEST
    val plannedDurationMinutes: Int,
    val actualDurationMinutes: Int,
    val focusedDurationMinutes: Int,
    val pauseDurationMinutes: Int = 0,
    val distractionsCount: Int = 0,
    val understandingRating: Int = 3, // 1 to 5
    val confidenceRating: Int = 3, // 1 to 5
    val difficultyRating: Int = 3, // 1 to 5
    val notes: String = "",
    val timestampEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_plan_tasks")
data class DailyPlanTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val dateString: String, // "YYYY-MM-DD"
    val priorityOrder: Int,
    val subjectName: String,
    val chapterName: String,
    val topicName: String,
    val taskType: String,
    val durationMinutes: Int,
    val reason: String,
    val expectedOutcome: String,
    val isCompleted: Boolean = false,
    val isLocked: Boolean = false,
    val isBacklog: Boolean = false,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "revision_items")
data class RevisionItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val topicId: Long,
    val topicName: String,
    val subjectName: String,
    val chapterName: String,
    val currentIntervalDay: Int = 1, // 0, 1, 3, 7, 14, 30
    val nextRevisionEpochMs: Long,
    val repetitionCount: Int = 0,
    val retentionScore: Int = 70,
    val lastRevisedEpochMs: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false
)

@Entity(tableName = "error_logs")
data class ErrorLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val subjectName: String,
    val chapterName: String,
    val topicName: String,
    val errorType: ErrorType,
    val questionSnippet: String,
    val studentMistake: String,
    val correctionNote: String,
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val isRepaired: Boolean = false
)

@Entity(tableName = "tests")
data class TestModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val title: String,
    val testType: String, // DIAGNOSTIC, UNIT_TEST, FULL_MOCK
    val durationMinutes: Int = 45,
    val totalMarks: Int = 40,
    val totalQuestions: Int = 10,
    val passingMarks: Int = 20,
    val isCompleted: Boolean = false,
    val scoreObtained: Float = 0f,
    val accuracyPct: Float = 0f,
    val aiDiagnosticReport: String = "",
    val timestampEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "test_questions")
data class TestQuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val testId: Long,
    val questionNumber: Int,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: String, // "A", "B", "C", "D"
    val explanation: String,
    val subjectName: String,
    val chapterName: String,
    val difficulty: String = "MEDIUM", // EASY, MEDIUM, HARD
    val positiveMarks: Float = 4f,
    val negativeMarks: Float = 1f,
    val selectedOption: String? = null,
    val isCorrect: Boolean = false,
    val timeSpentSeconds: Int = 0
)

@Entity(tableName = "blocked_apps")
data class BlockedAppEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isBlocked: Boolean = true,
    val category: String = "Social / Distraction"
)

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val focusMode: String = "Study Focus", // Study Focus, PYQ Focus, Mock Test Focus, Revision Focus
    val plannedMinutes: Int,
    val focusedMinutes: Int,
    val interruptionCount: Int = 0,
    val blockedAppAttempts: Int = 0,
    val exitEarly: Boolean = false,
    val efficiencyPct: Int = 100,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_audit_logs")
data class AiAuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val aiMode: String,
    val userPrompt: String,
    val aiOutputStructured: String,
    val appliedDirectly: Boolean = false,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "question_bank")
data class QuestionBankEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examName: String,
    val subjectName: String,
    val chapterName: String,
    val topicName: String,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: String, // "A", "B", "C", "D"
    val explanation: String,
    val difficulty: String = "MEDIUM", // EASY, MEDIUM, HARD
    val questionType: String = "CONCEPTUAL", // CONCEPTUAL, NUMERICAL, APPLICATION, LOGICAL, ASSERTION_REASON, PYQ_STYLE, AUTHENTIC_PYQ
    val sourceType: String = "AI_GENERATED", // AUTHENTIC_PYQ, PYQ_STYLE, AI_GENERATED, OFFICIAL
    val pyqYear: String = "",
    val fingerprint: String = "", // normalized unique hash for duplicate prevention
    val attemptCount: Int = 0,
    val correctCount: Int = 0,
    val incorrectCount: Int = 0,
    val lastAttemptedEpochMs: Long = 0,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "roadmap_versions")
data class RoadmapPlanVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val versionNumber: Int,
    val title: String,
    val reason: String,
    val planDaysJson: String, // serialized structured day-by-day roadmap
    val totalHours: Float,
    val dailyAverageHours: Float,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "student_availability")
data class StudentAvailabilityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val defaultDailyHours: Float = 3.5f,
    val weekendDailyHours: Float = 5.0f,
    val fixedCommitmentsText: String = "School 8 AM - 2 PM",
    val customDayHoursJson: String = "{}" // e.g. {"tomorrow": 2.0}
)

@Entity(tableName = "ai_action_audits")
data class AiActionAuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examId: Long,
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val userMessage: String,
    val intent: String,
    val actionType: String,
    val targetEntity: String,
    val oldValueJson: String = "",
    val newValueJson: String = "",
    val status: String = "APPLIED", // APPLIED, ROLLED_BACK
    val summaryDescription: String
)

