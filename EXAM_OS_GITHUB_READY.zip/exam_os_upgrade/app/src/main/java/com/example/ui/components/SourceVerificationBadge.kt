package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VerificationStatus
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.AmberGold
import com.example.ui.theme.VioletPurple

@Composable
fun SourceVerificationBadge(
    status: VerificationStatus,
    sourceName: String = "",
    modifier: Modifier = Modifier
) {
    val (badgeColor, icon, text) = when (status) {
        VerificationStatus.OFFICIAL -> Triple(EmeraldNeon, Icons.Default.Verified, "OFFICIAL")
        VerificationStatus.VERIFIED_SECONDARY -> Triple(ElectricBlue, Icons.Default.CheckCircle, "VERIFIED")
        VerificationStatus.UNVERIFIED -> Triple(AmberGold, Icons.Default.Info, "UNVERIFIED")
        VerificationStatus.AI_INFERENCE -> Triple(VioletPurple, Icons.Default.AutoAwesome, "AI INFERRED")
    }

    Box(
        modifier = modifier
            .background(badgeColor.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
            .border(1.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = badgeColor,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (sourceName.isNotBlank()) "$text • $sourceName" else text,
                color = badgeColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}
