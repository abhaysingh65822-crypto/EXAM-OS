package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ai.AiStudyOsScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.errors.ErrorDoctorScreen
import com.example.ui.screens.onboarding.OnboardingScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.study.FocusManagerScreen
import com.example.ui.screens.syllabus.SyllabusBrowserScreen
import com.example.ui.screens.tests.MockTestScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.ExamOsViewModel

enum class Screen {
    ONBOARDING,
    DASHBOARD,
    SYLLABUS,
    FOCUS,
    TESTS,
    ERRORS,
    AI_OS,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                ExamOsApp()
            }
        }
    }
}

@Composable
fun ExamOsApp(
    viewModel: ExamOsViewModel = viewModel()
) {
    val activeProfile by viewModel.activeProfile.collectAsState()
    var currentScreen by remember { mutableStateOf<Screen?>(null) }

    val effectiveScreen = currentScreen ?: if (activeProfile == null) Screen.ONBOARDING else Screen.DASHBOARD

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Slate950,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        androidx.compose.foundation.layout.Box(modifier = Modifier.padding(innerPadding)) {
            when (effectiveScreen) {
                Screen.ONBOARDING -> {
                    OnboardingScreen(
                        viewModel = viewModel,
                        onSetupFinished = { currentScreen = Screen.DASHBOARD }
                    )
                }

                Screen.DASHBOARD -> {
                    DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToSyllabus = { currentScreen = Screen.SYLLABUS },
                        onNavigateToFocus = { currentScreen = Screen.FOCUS },
                        onNavigateToTests = { currentScreen = Screen.TESTS },
                        onNavigateToErrors = { currentScreen = Screen.ERRORS },
                        onNavigateToAi = { currentScreen = Screen.AI_OS },
                        onNavigateToSettings = { currentScreen = Screen.SETTINGS }
                    )
                }

                Screen.SYLLABUS -> {
                    BackHandler { currentScreen = Screen.DASHBOARD }
                    SyllabusBrowserScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                }

                Screen.FOCUS -> {
                    BackHandler { currentScreen = Screen.DASHBOARD }
                    FocusManagerScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                }

                Screen.TESTS -> {
                    BackHandler { currentScreen = Screen.DASHBOARD }
                    MockTestScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                }

                Screen.ERRORS -> {
                    BackHandler { currentScreen = Screen.DASHBOARD }
                    ErrorDoctorScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                }

                Screen.AI_OS -> {
                    BackHandler { currentScreen = Screen.DASHBOARD }
                    AiStudyOsScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD }
                    )
                }

                Screen.SETTINGS -> {
                    BackHandler { currentScreen = Screen.DASHBOARD }
                    SettingsScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = Screen.DASHBOARD },
                        onResetSetup = { currentScreen = Screen.ONBOARDING }
                    )
                }
            }
        }
    }
}
