package com.example.ui.screens.errors

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun ErrorDoctorScreen(viewModel: ExamOsViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Error Doctor", style = MaterialTheme.typography.headlineMedium)
        Text("Turn mistakes into targeted repair tasks, revision and future test weighting.")
        Button(onClick = { viewModel.sendAiMessage("Analyze my recent errors and rebuild my roadmap") }) { Text("AI repair my weak areas") }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
