package com.example.ui.screens.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun OnboardingScreen(viewModel: ExamOsViewModel, onSetupFinished: () -> Unit) {
    var exam by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() + 90L * 86400000L))) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("EXAM OS", style = MaterialTheme.typography.displaySmall)
        Text("Tell me the exam and date. I’ll build the study operating system.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(exam, { exam = it }, label = { Text("Exam name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(date, { date = it }, label = { Text("Exam date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Button(onClick = {
            val ms = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)?.time ?: 0L }.getOrDefault(0L)
            if (exam.isNotBlank() && ms > System.currentTimeMillis()) { viewModel.setupExam(exam, ms); onSetupFinished() }
        }, modifier = Modifier.fillMaxWidth()) { Text("Build my adaptive plan") }
    }
}
