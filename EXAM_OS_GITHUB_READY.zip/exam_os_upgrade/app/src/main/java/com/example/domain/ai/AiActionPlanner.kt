package com.example.domain.ai

import com.example.data.api.AiProvider
import com.example.data.api.GeminiContent
import org.json.JSONObject

/**
 * AI-assisted intent extraction for natural multi-fact messages.
 * The deterministic classifier remains the fallback/source of truth for execution rules.
 */
class AiActionPlanner(private val provider: AiProvider) {
    suspend fun propose(message: String, context: String): StructuredAiAction? {
        val prompt = """
            Convert the student's request into ONE structured Exam OS action.
            Return ONLY JSON, no markdown:
            {"action":"NONE|REBUILD_ROADMAP|UPDATE_AVAILABILITY|UPDATE_TOPIC_PROGRESS|UPDATE_WEAKNESS|GENERATE_TEST_QUESTIONS|CREATE_MOCK_TEST|SYNC_SYLLABUS|WHAT_IF_SIMULATION|START_STUDY_SESSION|ADD_SUBJECT|ADD_CHAPTER|COMPLETE_ROADMAP_DAY|LOCK_ROADMAP_DAY","subject":"","chapter":"","topic":"","hours":0,"count":0,"day":0,"duration":0,"details":""}
            Do not invent an exam, date, subject or chapter. Use empty values when absent.
            Context: $context
            Student: $message
        """.trimIndent()
        val result = provider.generateResponse(prompt, "You are the structured command parser for a study app. Output strict JSON only.", emptyList())
        if (!result.isSuccess) return null
        val raw = result.getOrNull()?.trim().orEmpty().removePrefix("```").removeSuffix("```").trim()
        return runCatching {
            val o = JSONObject(raw)
            val action = o.optString("action", "NONE")
            val type = runCatching { AiActionType.valueOf(action) }.getOrNull() ?: return null
            val permission = when (type) {
                AiActionType.CREATE_MOCK_TEST, AiActionType.GENERATE_TEST_QUESTIONS,
                AiActionType.REBUILD_ROADMAP, AiActionType.UPDATE_AVAILABILITY,
                AiActionType.UPDATE_TOPIC_PROGRESS, AiActionType.UPDATE_WEAKNESS,
                AiActionType.SYNC_SYLLABUS, AiActionType.START_STUDY_SESSION,
                AiActionType.ADD_SUBJECT, AiActionType.ADD_CHAPTER,
                AiActionType.COMPLETE_ROADMAP_DAY, AiActionType.LOCK_ROADMAP_DAY -> ToolPermission.LOW_RISK_WRITE
                else -> ToolPermission.READ_ONLY
            }
            StructuredAiAction(
                actionType = type,
                permission = permission,
                targetSubject = o.optString("subject"),
                targetChapter = o.optString("chapter"),
                targetTopic = o.optString("topic"),
                hoursAvailable = o.optDouble("hours", 0.0).toFloat(),
                questionCount = o.optInt("count", 0),
                targetDayNumber = o.optInt("day", 1).coerceAtLeast(1),
                durationMinutes = o.optInt("duration", 30).coerceIn(5, 720),
                details = o.optString("details")
            )
        }.getOrNull()
    }
}
