package com.example.domain.syllabus

import com.example.data.db.ExamChapterEntity
import com.example.data.db.ExamProfileEntity
import com.example.data.db.ExamSubjectEntity
import com.example.data.db.ExamTopicEntity
import com.example.data.model.TopicStatus
import com.example.data.model.VerificationStatus
import com.example.domain.DiscoveredExamData
import com.example.domain.ai.SyllabusSyncDiff

object SyllabusSyncEngine {

    fun computeDiff(
        currentSubjects: List<ExamSubjectEntity>,
        currentChapters: List<ExamChapterEntity>,
        discovered: DiscoveredExamData
    ): SyllabusSyncDiff {
        val currentSubNames = currentSubjects.map { it.name.trim().lowercase() }.toSet()
        val discoveredSubNames = discovered.subjects.map { it.name.trim().lowercase() }.toSet()

        val missingSubs = discovered.subjects.filter { it.name.trim().lowercase() !in currentSubNames }.map { it.name }
        val extraSubs = currentSubjects.filter { it.name.trim().lowercase() !in discoveredSubNames }.map { it.name }

        val currentChapNames = currentChapters.map { it.name.trim().lowercase() }.toSet()
        val allDiscoveredChapters = discovered.chaptersMap.values.flatten()
        val discoveredChapNames = allDiscoveredChapters.map { it.name.trim().lowercase() }.toSet()

        val missingChaps = allDiscoveredChapters.filter { it.name.trim().lowercase() !in currentChapNames }.map { it.name }
        val extraChaps = currentChapters.filter { it.name.trim().lowercase() !in discoveredChapNames }.map { it.name }

        return SyllabusSyncDiff(
            examName = discovered.profile.examName,
            missingSubjects = missingSubs,
            extraSubjects = extraSubs,
            missingChapters = missingChaps,
            extraChapters = extraChaps,
            missingTopics = emptyList(),
            conflicts = emptyList()
        )
    }

    fun getCanonicalCbseClass10Syllabus(targetDateEpochMs: Long): DiscoveredExamData {
        val profile = ExamProfileEntity(
            examName = "CBSE Class 10 Board 2027",
            targetExamDateEpochMs = targetDateEpochMs,
            studentName = "CBSE Scholar",
            targetScoreDesc = "95%+ (A1 in all subjects)",
            conductingBody = "Central Board of Secondary Education (CBSE)",
            academicYear = "2026-2027",
            durationMinutes = 180,
            totalMarks = 500, // 5 subjects x 100
            totalQuestions = 39,
            positiveMarks = 1,
            negativeMarks = 0.0f,
            sectionsSummary = "Section A (20 MCQs), Section B (Short), Section C (Long), Section D (Case-Based)",
            officialWebsiteUrl = "https://cbseacademic.nic.in",
            sourceName = "CBSE Official Secondary Curriculum 2026/27",
            verificationStatus = VerificationStatus.OFFICIAL,
            retrievalDate = "October 2026",
            readinessScore = 20
        )

        val subjects = listOf(
            ExamSubjectEntity(examId = 0, name = "Science", iconKey = "science", weightagePct = 25, estimatedHours = 90, orderIndex = 1),
            ExamSubjectEntity(examId = 0, name = "Mathematics", iconKey = "calculate", weightagePct = 25, estimatedHours = 95, orderIndex = 2),
            ExamSubjectEntity(examId = 0, name = "Social Science", iconKey = "public", weightagePct = 25, estimatedHours = 75, orderIndex = 3),
            ExamSubjectEntity(examId = 0, name = "English Language & Literature", iconKey = "menu_book", weightagePct = 25, estimatedHours = 50, orderIndex = 4)
        )

        val chaptersMap = mapOf(
            "Science" to listOf(
                ExamChapterEntity(subjectId = 0, name = "Chemical Reactions and Equations", importance = "HIGH", pyqQuestionCount = 28, orderIndex = 1),
                ExamChapterEntity(subjectId = 0, name = "Acids, Bases and Salts", importance = "HIGH", pyqQuestionCount = 24, orderIndex = 2),
                ExamChapterEntity(subjectId = 0, name = "Metals and Non-metals", importance = "HIGH", pyqQuestionCount = 26, orderIndex = 3),
                ExamChapterEntity(subjectId = 0, name = "Carbon and its Compounds", importance = "HIGH", pyqQuestionCount = 35, orderIndex = 4),
                ExamChapterEntity(subjectId = 0, name = "Life Processes", importance = "HIGH", pyqQuestionCount = 38, orderIndex = 5),
                ExamChapterEntity(subjectId = 0, name = "Control and Coordination", importance = "MEDIUM", pyqQuestionCount = 22, orderIndex = 6),
                ExamChapterEntity(subjectId = 0, name = "How do Organisms Reproduce?", importance = "HIGH", pyqQuestionCount = 30, orderIndex = 7),
                ExamChapterEntity(subjectId = 0, name = "Heredity and Evolution", importance = "MEDIUM", pyqQuestionCount = 20, orderIndex = 8),
                ExamChapterEntity(subjectId = 0, name = "Light – Reflection and Refraction", importance = "HIGH", pyqQuestionCount = 42, orderIndex = 9),
                ExamChapterEntity(subjectId = 0, name = "Human Eye and Colourful World", importance = "MEDIUM", pyqQuestionCount = 18, orderIndex = 10),
                ExamChapterEntity(subjectId = 0, name = "Electricity", importance = "HIGH", pyqQuestionCount = 45, orderIndex = 11),
                ExamChapterEntity(subjectId = 0, name = "Magnetic Effects of Electric Current", importance = "HIGH", pyqQuestionCount = 32, orderIndex = 12),
                ExamChapterEntity(subjectId = 0, name = "Our Environment", importance = "MEDIUM", pyqQuestionCount = 15, orderIndex = 13)
            ),
            "Mathematics" to listOf(
                ExamChapterEntity(subjectId = 0, name = "Real Numbers", importance = "MEDIUM", pyqQuestionCount = 20, orderIndex = 1),
                ExamChapterEntity(subjectId = 0, name = "Polynomials", importance = "HIGH", pyqQuestionCount = 25, orderIndex = 2),
                ExamChapterEntity(subjectId = 0, name = "Pair of Linear Equations in Two Variables", importance = "HIGH", pyqQuestionCount = 32, orderIndex = 3),
                ExamChapterEntity(subjectId = 0, name = "Quadratic Equations", importance = "HIGH", pyqQuestionCount = 40, orderIndex = 4),
                ExamChapterEntity(subjectId = 0, name = "Arithmetic Progressions", importance = "HIGH", pyqQuestionCount = 30, orderIndex = 5),
                ExamChapterEntity(subjectId = 0, name = "Triangles", importance = "HIGH", pyqQuestionCount = 36, orderIndex = 6),
                ExamChapterEntity(subjectId = 0, name = "Coordinate Geometry", importance = "HIGH", pyqQuestionCount = 28, orderIndex = 7),
                ExamChapterEntity(subjectId = 0, name = "Introduction to Trigonometry", importance = "HIGH", pyqQuestionCount = 44, orderIndex = 8),
                ExamChapterEntity(subjectId = 0, name = "Some Applications of Trigonometry (Heights & Distances)", importance = "HIGH", pyqQuestionCount = 28, orderIndex = 9),
                ExamChapterEntity(subjectId = 0, name = "Circles", importance = "HIGH", pyqQuestionCount = 26, orderIndex = 10),
                ExamChapterEntity(subjectId = 0, name = "Areas Related to Circles", importance = "MEDIUM", pyqQuestionCount = 22, orderIndex = 11),
                ExamChapterEntity(subjectId = 0, name = "Surface Areas and Volumes", importance = "HIGH", pyqQuestionCount = 34, orderIndex = 12),
                ExamChapterEntity(subjectId = 0, name = "Statistics", importance = "HIGH", pyqQuestionCount = 30, orderIndex = 13),
                ExamChapterEntity(subjectId = 0, name = "Probability", importance = "MEDIUM", pyqQuestionCount = 18, orderIndex = 14)
            ),
            "Social Science" to listOf(
                ExamChapterEntity(subjectId = 0, name = "The Rise of Nationalism in Europe", importance = "HIGH", pyqQuestionCount = 25, orderIndex = 1),
                ExamChapterEntity(subjectId = 0, name = "Nationalism in India", importance = "HIGH", pyqQuestionCount = 32, orderIndex = 2),
                ExamChapterEntity(subjectId = 0, name = "Resources and Development & Agriculture", importance = "HIGH", pyqQuestionCount = 28, orderIndex = 3),
                ExamChapterEntity(subjectId = 0, name = "Power Sharing & Federalism", importance = "HIGH", pyqQuestionCount = 26, orderIndex = 4),
                ExamChapterEntity(subjectId = 0, name = "Money and Credit & Globalisation", importance = "HIGH", pyqQuestionCount = 24, orderIndex = 5)
            )
        )

        val topicsMap = mapOf(
            "Electricity" to listOf(
                ExamTopicEntity(chapterId = 0, name = "Electric Current, Potential Difference & Ohm's Law", estimatedMinutes = 45, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL),
                ExamTopicEntity(chapterId = 0, name = "Factors affecting Resistance & Resistivity", estimatedMinutes = 40, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL),
                ExamTopicEntity(chapterId = 0, name = "Series and Parallel Combinations of Resistors", estimatedMinutes = 55, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL),
                ExamTopicEntity(chapterId = 0, name = "Heating Effect of Electric Current (Joule's Law) & Electric Power", estimatedMinutes = 45, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL)
            ),
            "Quadratic Equations" to listOf(
                ExamTopicEntity(chapterId = 0, name = "Standard Form & Solutions by Factorisation", estimatedMinutes = 45, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL),
                ExamTopicEntity(chapterId = 0, name = "Quadratic Formula & Derivation", estimatedMinutes = 40, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL),
                ExamTopicEntity(chapterId = 0, name = "Nature of Roots & Discriminant Analysis", estimatedMinutes = 50, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL),
                ExamTopicEntity(chapterId = 0, name = "Real-World Word Problems on Speed, Work & Areas", estimatedMinutes = 60, status = TopicStatus.NOT_STARTED, sourceName = "CBSE Curriculum", verificationStatus = VerificationStatus.OFFICIAL)
            )
        )

        return DiscoveredExamData(profile, subjects, chaptersMap, topicsMap)
    }
}
