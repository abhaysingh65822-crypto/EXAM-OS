package com.example.data.repository

import com.example.data.db.DailyPlanTaskEntity
import com.example.data.db.ExamDao
import com.example.data.db.ExamProfileEntity
import com.example.data.model.TopicStatus
import com.example.domain.CountdownStrategyEngine
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StudyPlannerRepository(private val dao: ExamDao) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getTodayDateString(): String = dateFormat.format(Date())

    fun getTodayTasksFlow(): Flow<List<DailyPlanTaskEntity>> = dao.getTasksForDateFlow(getTodayDateString())

    val pendingTasksFlow: Flow<List<DailyPlanTaskEntity>> = dao.getPendingTasksFlow()

    suspend fun generateOrUpdateTodayPlan(profile: ExamProfileEntity): List<DailyPlanTaskEntity> {
        val todayStr = getTodayDateString()
        val existingTasks = dao.getTasksForDate(todayStr)
        if (existingTasks.isNotEmpty()) {
            return existingTasks
        }

        val chapters = dao.getAllChapters()
        val phase = CountdownStrategyEngine.determinePhase(
            CountdownStrategyEngine.getDaysRemaining(profile.targetExamDateEpochMs)
        )

        val newTasks = mutableListOf<DailyPlanTaskEntity>()
        var order = 1

        // High priority: Urgent or weak chapter
        val weakChapter = chapters.filter { it.importance == "HIGH" && it.masteryScore < 60 }
            .minByOrNull { it.masteryScore }
            ?: chapters.firstOrNull()

        if (weakChapter != null) {
            newTasks.add(
                DailyPlanTaskEntity(
                    examId = profile.id,
                    dateString = todayStr,
                    priorityOrder = order++,
                    subjectName = "Priority Subject",
                    chapterName = weakChapter.name,
                    topicName = "Core Concept Mastery & Derivations",
                    taskType = "THEORY",
                    durationMinutes = 45,
                    reason = "Chapter mastery is currently at ${weakChapter.masteryScore}% with high exam weightage.",
                    expectedOutcome = "Complete core derivation sequence and clarify formula conditions."
                )
            )

            newTasks.add(
                DailyPlanTaskEntity(
                    examId = profile.id,
                    dateString = todayStr,
                    priorityOrder = order++,
                    subjectName = "Priority Subject",
                    chapterName = weakChapter.name,
                    topicName = "High-Yield PYQ Set (15-20 Questions)",
                    taskType = "PYQ",
                    durationMinutes = 40,
                    reason = "Direct exam pattern alignment and recurring question types.",
                    expectedOutcome = "Achieve >75% accuracy and log any calculation or formula errors."
                )
            )
        }

        // Secondary priority: Second subject for balanced interleaving
        val secondaryChapter = chapters.filter { it.id != weakChapter?.id }
            .minByOrNull { it.masteryScore }
            ?: chapters.getOrNull(1)

        if (secondaryChapter != null) {
            newTasks.add(
                DailyPlanTaskEntity(
                    examId = profile.id,
                    dateString = todayStr,
                    priorityOrder = order++,
                    subjectName = "Secondary Subject",
                    chapterName = secondaryChapter.name,
                    topicName = "Problem Solving & Analytical Practice",
                    taskType = "PRACTICE",
                    durationMinutes = 40,
                    reason = "Prevents subject fatigue via cognitive interleaving.",
                    expectedOutcome = "Solve 12 medium-hard problems under 3 min/question pace."
                )
            )
        }

        // Active Recall / Revision block
        newTasks.add(
            DailyPlanTaskEntity(
                examId = profile.id,
                dateString = todayStr,
                priorityOrder = order++,
                subjectName = "Consolidation",
                chapterName = "Active Recall Review",
                topicName = "Formula Flash Sheet & Mistake Log Review",
                taskType = "REVISION",
                durationMinutes = 25,
                reason = "Nightly consolidation protects retention curve against decay.",
                expectedOutcome = "Zero hesitation recall on critical formulas and previous errors."
            )
        )

        dao.insertDailyTasks(newTasks)
        return newTasks
    }

    suspend fun toggleTaskCompletion(task: DailyPlanTaskEntity) {
        val updated = task.copy(isCompleted = !task.isCompleted)
        dao.updateDailyTask(updated)
    }

    suspend fun addNewCustomTask(task: DailyPlanTaskEntity) {
        dao.insertDailyTask(task)
    }

    suspend fun deleteTask(task: DailyPlanTaskEntity) {
        dao.deleteDailyTask(task)
    }
}
