package com.example.domain.ai

import com.example.data.api.AiProvider
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiPart
import com.example.data.db.AiActionAuditEntity
import com.example.data.db.ExamDao
import com.example.data.model.TopicStatus
import com.example.data.model.UserControlMode
import com.example.domain.CountdownStrategyEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ControllerAgentResponse(
    val conversationalReply: String,
    val structuredAction: StructuredAiAction?,
    val executionResult: AiActionResult?
)

enum class EmotionalTone {
    FRUSTRATED_OVERWHELMED,
    BEHIND_SCHEDULE,
    CONFIDENT_CELEBRATING,
    LOW_ENERGY_PROCRASTINATING,
    NEUTRAL
}

class AutonomousStudyOsController(
    private val dao: ExamDao,
    private val toolRegistry: AiToolRegistry,
    private val aiProvider: AiProvider
) {
    private val aiActionPlanner = AiActionPlanner(aiProvider)

    suspend fun processUserMessage(
        userMessage: String,
        chatHistory: List<GeminiContent> = emptyList()
    ): ControllerAgentResponse = withContext(Dispatchers.IO) {
        val trimmed = userMessage.trim()
        val emotionalTone = detectEmotionalTone(trimmed)
        val coachingHeader = getEmotionalCoachingHeader(emotionalTone)

        // Ambiguity check: e.g. "Maths complete hai" or "Science complete"
        if ((trimmed.equals("maths complete", ignoreCase = true) ||
             trimmed.equals("maths complete hai", ignoreCase = true) ||
             trimmed.equals("science complete", ignoreCase = true) ||
             trimmed.equals("science complete hai", ignoreCase = true)) &&
            !trimmed.contains("chapter") && !trimmed.contains("pyq")
        ) {
            val sub = if (trimmed.contains("math")) "Mathematics" else "Science"
            val reply = """
                $coachingHeader$sub ke baare mein ek clarification chahiye:
                Complete se tumhara matlab poora syllabus aur PYQs/questions dono ho gaye hain, ya sirf chapters padhe hain?
                
                • Agar PYQs bhi complete hain: Bol do "Full $sub with PYQs done", to main 100% mastery lock karke mock tests schedule kar doonga.
                • Agar sirf reading hui hai: Main chapter-wise problem sets roadmap mein preserve rakhunga.
            """.trimIndent()
            return@withContext ControllerAgentResponse(reply, null, null)
        }

        val intents = AiIntentClassifier.classify(trimmed)
        val primaryIntent = intents.firstOrNull() ?: ClassifiedIntent(StudentIntent.GENERAL_CHAT, IntentConfidence.LOW)

        // Retrieve current exam context
        val activeExam = dao.getActiveExamProfile()
        val daysLeft = if (activeExam != null) CountdownStrategyEngine.getDaysRemaining(activeExam.targetExamDateEpochMs) else 60

        // Multi-fact action planner: construct actions for each recognized intent
        val plannedActions = mutableListOf<StructuredAiAction>()

        // If the deterministic classifier cannot confidently map the message, let the AI
        // extract a structured command. Execution still goes through the registered tools.
        if (primaryIntent.intent == StudentIntent.GENERAL_CHAT || primaryIntent.confidence == IntentConfidence.LOW) {
            val context = "exam=${activeExam?.examName ?: "none"}; daysLeft=$daysLeft; today=${toolRegistry.getTodayPlanSummary()}"
            aiActionPlanner.propose(trimmed, context)?.let { proposed ->
                if (proposed.actionType != AiActionType.UPDATE_EXAM_SETTINGS || proposed.details.isNotBlank()) {
                    plannedActions.add(proposed)
                }
            }
        }

        for (item in intents) {
            when (item.intent) {
                StudentIntent.SETUP_EXAM -> {
                    val examName = item.extractedEntities["exam"] ?: "UP Board Class 10 High School 2027"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.SETUP_EXAM_CURRICULUM,
                            permission = ToolPermission.CONFIRM_REQUIRED,
                            examName = examName,
                            details = "Autonomous Setup for $examName",
                            targetTotalDays = 366
                        )
                    )
                }

                StudentIntent.REBUILD_ROADMAP, StudentIntent.REPORT_MISSED_TASK -> {
                    val days = item.extractedEntities["days"]?.toIntOrNull() ?: 366
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.REBUILD_ROADMAP,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetTotalDays = days,
                            details = "Rebuild roadmap with $days days power"
                        )
                    )
                }

                StudentIntent.LOCK_DAY -> {
                    val dayNum = item.extractedEntities["day"]?.toIntOrNull() ?: 1
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.LOCK_ROADMAP_DAY,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetDayNumber = dayNum,
                            details = "Toggle lock on Day $dayNum"
                        )
                    )
                }

                StudentIntent.COMPLETE_DAY -> {
                    val dayNum = item.extractedEntities["day"]?.toIntOrNull() ?: 1
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.COMPLETE_ROADMAP_DAY,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetDayNumber = dayNum,
                            details = "Mark Day $dayNum completed"
                        )
                    )
                }

                StudentIntent.START_SESSION -> {
                    val subject = item.extractedEntities["subject"] ?: "Mathematics"
                    val chapter = item.extractedEntities["chapter"] ?: "Target Chapter"
                    val duration = item.extractedEntities["duration"]?.toIntOrNull() ?: 30
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.START_STUDY_SESSION,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = subject,
                            targetChapter = chapter,
                            durationMinutes = duration,
                            details = "Launch $duration min session for $subject: $chapter"
                        )
                    )
                }

                StudentIntent.STOP_SESSION -> {
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.STOP_STUDY_SESSION,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            details = "Stop active study focus session"
                        )
                    )
                }

                StudentIntent.ADD_SUBJECT -> {
                    val sub = item.extractedEntities["subject"] ?: "Computer Science"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.ADD_SUBJECT,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = sub,
                            details = "Add subject $sub to curriculum"
                        )
                    )
                }

                StudentIntent.DELETE_SUBJECT -> {
                    val sub = item.extractedEntities["subject"] ?: "Subject"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.DELETE_SUBJECT,
                            permission = ToolPermission.DESTRUCTIVE,
                            targetSubject = sub,
                            details = "Remove subject $sub"
                        )
                    )
                }

                StudentIntent.ADD_CHAPTER -> {
                    val sub = item.extractedEntities["subject"] ?: "Science"
                    val chap = item.extractedEntities["chapter"] ?: "New Concept"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.ADD_CHAPTER,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = sub,
                            targetChapter = chap,
                            details = "Add chapter $chap under $sub"
                        )
                    )
                }

                StudentIntent.DELETE_CHAPTER -> {
                    val chap = item.extractedEntities["chapter"] ?: "Chapter"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.DELETE_CHAPTER,
                            permission = ToolPermission.DESTRUCTIVE,
                            targetChapter = chap,
                            details = "Delete chapter $chap"
                        )
                    )
                }

                StudentIntent.UPDATE_EXAM_SETTINGS -> {
                    val score = item.extractedEntities["score"] ?: "95%+"
                    val hours = item.extractedEntities["hours"]?.toFloatOrNull() ?: 4f
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.UPDATE_EXAM_SETTINGS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetScore = score,
                            hoursAvailable = hours,
                            details = "Update target score to $score and hours to $hours"
                        )
                    )
                }

                StudentIntent.SWITCH_CONTROL_MODE -> {
                    val modeStr = item.extractedEntities["mode"] ?: UserControlMode.AUTO.name
                    val mode = runCatching { UserControlMode.valueOf(modeStr) }.getOrDefault(UserControlMode.AUTO)
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.SWITCH_CONTROL_MODE,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            controlMode = mode,
                            details = "Switch control mode to ${mode.displayName}"
                        )
                    )
                }

                StudentIntent.RESET_ROADMAP -> {
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.RESET_ROADMAP,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetTotalDays = 366,
                            details = "Reset and regenerate 366-day roadmap"
                        )
                    )
                }

                StudentIntent.UPDATE_PROGRESS -> {
                    val subject = item.extractedEntities["subject"] ?: "Curriculum"
                    val chapter = item.extractedEntities["chapter"] ?: "All Chapters"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.UPDATE_TOPIC_PROGRESS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = subject,
                            targetChapter = chapter,
                            targetStatus = TopicStatus.MASTERED
                        )
                    )
                }

                StudentIntent.REPORT_WEAKNESS -> {
                    val subject = item.extractedEntities["subject"] ?: "Science"
                    val chapter = item.extractedEntities["chapter"] ?: "Quadratic Equations"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.UPDATE_WEAKNESS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = subject,
                            targetChapter = chapter
                        )
                    )
                }

                StudentIntent.REPORT_STRENGTH -> {
                    val subject = item.extractedEntities["subject"] ?: "Curriculum"
                    val chapter = item.extractedEntities["chapter"] ?: "Target Chapter"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.UPDATE_TOPIC_PROGRESS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = subject,
                            targetChapter = chapter,
                            targetStatus = TopicStatus.MASTERED,
                            details = "Marked $chapter in $subject as strong"
                        )
                    )
                }

                StudentIntent.MODIFY_SYLLABUS -> {
                    val subject = item.extractedEntities["subject"] ?: "Custom Subject"
                    val chapter = item.extractedEntities["chapter"] ?: "Custom Chapter"
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.UPDATE_TOPIC_PROGRESS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = subject,
                            targetChapter = chapter,
                            details = "Syllabus adjusted: $chapter in $subject"
                        )
                    )
                }

                StudentIntent.CHANGE_AVAILABILITY -> {
                    val hours = item.extractedEntities["hours"]?.toFloatOrNull() ?: 2.0f
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.UPDATE_AVAILABILITY,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            hoursAvailable = hours,
                            details = "Adjust study slot to $hours hours"
                        )
                    )
                }

                StudentIntent.GENERATE_QUESTIONS, StudentIntent.CREATE_MOCK -> {
                    val count = item.extractedEntities["count"]?.toIntOrNull() ?: 50
                    val subject = item.extractedEntities["subject"] ?: "Science & Mathematics"
                    val chapter = item.extractedEntities["chapter"] ?: ""
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = if (item.intent == StudentIntent.CREATE_MOCK) AiActionType.CREATE_MOCK_TEST else AiActionType.GENERATE_TEST_QUESTIONS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            targetSubject = subject,
                            targetChapter = chapter,
                            questionCount = count
                        )
                    )
                }

                StudentIntent.CLEAR_TEST_HISTORY -> {
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.CLEAR_TEST_HISTORY,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            details = "Synchronize diagnostics and test telemetry"
                        )
                    )
                }

                StudentIntent.SYNC_SYLLABUS -> {
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.SYNC_SYLLABUS,
                            permission = ToolPermission.LOW_RISK_WRITE,
                            details = "Official syllabus check"
                        )
                    )
                }

                StudentIntent.WHAT_IF_QUERY -> {
                    val hours = if (trimmed.contains("4")) 4.0f else if (trimmed.contains("2")) 2.0f else 5.0f
                    plannedActions.add(
                        StructuredAiAction(
                            actionType = AiActionType.WHAT_IF_SIMULATION,
                            permission = ToolPermission.READ_ONLY,
                            hoursAvailable = hours,
                            details = userMessage
                        )
                    )
                }

                StudentIntent.WHAT_SHOULD_I_DO_NOW -> {
                    val nextTask = toolRegistry.getTodayPlanSummary()
                    val reply = """
                        $coachingHeader[AUTONOMOUS ROADMAP TODAY'S PRIORITY]
                        • Remaining Time Today: Focus slot open
                        • Days Left to Exam: $daysLeft days
                        
                        Top Action:
                        $nextTask
                        
                        Reason:
                        - Directly aligns with your highest-weightage exam targets.
                        - Spaced retention window is active.
                    """.trimIndent()

                    return@withContext ControllerAgentResponse(
                        conversationalReply = reply,
                        structuredAction = null,
                        executionResult = null
                    )
                }

                StudentIntent.GENERAL_CHAT -> {}
            }
        }

        // Execute all actions safely in transaction-like sequence
        var primaryResult: AiActionResult? = null
        val accumulatedChanges = mutableListOf<String>()

        for (action in plannedActions) {
            val res = toolRegistry.executeAction(action, userMessage)
            if (primaryResult == null) {
                primaryResult = res
            }
            accumulatedChanges.addAll(res.changesApplied)

            // Audit the action
            dao.insertAiActionAudit(
                AiActionAuditEntity(
                    examId = activeExam?.id ?: 1,
                    userMessage = userMessage,
                    intent = primaryIntent.intent.name,
                    actionType = action.actionType.name,
                    targetEntity = "${action.targetSubject} / ${action.targetChapter}",
                    summaryDescription = res.summaryMessage
                )
            )
        }

        val currentPrimaryResult = primaryResult

        // Rebuild explanation incorporating coaching header
        val finalResponseText = if (currentPrimaryResult != null) {
            val baseExplanation = buildActionResponseExplanation(
                primaryIntent.intent,
                plannedActions.first(),
                currentPrimaryResult.copy(changesApplied = accumulatedChanges.distinct()),
                daysLeft
            )
            coachingHeader + baseExplanation
        } else {
            val providerResponse = aiProvider.generateResponse(
                prompt = userMessage,
                systemInstruction = "You are Exam OS Google Search Grounded AI Bot for ${activeExam?.examName ?: "CBSE Board Class 10th"}. Provide accurate, up-to-date facts, syllabus topics, formulas, step-by-step solutions, and exam tips.",
                chatHistory = chatHistory
            )
            val replyText = if (providerResponse.isSuccess && !providerResponse.getOrNull().isNullOrBlank()) {
                providerResponse.getOrNull()!!
            } else {
                generateGroundedChatResponse(userMessage, activeExam?.examName ?: "Exam", daysLeft)
            }
            coachingHeader + replyText
        }

        ControllerAgentResponse(
            conversationalReply = finalResponseText,
            structuredAction = plannedActions.firstOrNull(),
            executionResult = primaryResult
        )
    }

    suspend fun processUserImage(
        imageBytes: ByteArray,
        mimeType: String,
        userPrompt: String
    ): ControllerAgentResponse = withContext(Dispatchers.IO) {
        val activeExam = dao.getActiveExamProfile()
        val daysLeft = if (activeExam != null) CountdownStrategyEngine.getDaysRemaining(activeExam.targetExamDateEpochMs) else 60

        if (!aiProvider.supportsVision) {
            val reply = """
                [IMAGE RECEIVED • VISION PROVIDER REQUIRED]
                Google Search AI is currently active (text-grounded).
                To analyze questions, handwritten solutions, syllabus snapshots, or timetables from photos, please select 'Gemini API (Optional)' in the header above or configure your Gemini API key in Settings.
                
                Alternatively, you can type the question text directly and I will diagnose it right away!
            """.trimIndent()
            return@withContext ControllerAgentResponse(
                conversationalReply = reply,
                structuredAction = null,
                executionResult = null
            )
        }

        val promptForVision = if (userPrompt.isNotBlank()) {
            userPrompt
        } else {
            "Solve this question step-by-step with clear formulas and conceptual reasoning. Point out potential exam traps."
        }

        val visionResult = aiProvider.analyzeImage(
            imageBytes = imageBytes,
            mimeType = mimeType,
            prompt = promptForVision
        )

        val reply = if (visionResult.isSuccess && !visionResult.getOrNull().isNullOrBlank()) {
            """
                📷 [IMAGE IMPORT ANALYSER • AI SOLUTION]
                
                ${visionResult.getOrNull()}
                
                • Recommended Action: Add this concept to your study queue or practice similar questions in Mock Tests.
            """.trimIndent()
        } else {
            """
                📷 [IMAGE ANALYSIS RESULT]
                Received study visual (${imageBytes.size / 1024} KB).
                The visual has been indexed into your study vault.
                
                If you need a specific derivation or step checked, type: "Solve question 4 from image" or check your internet connectivity.
            """.trimIndent()
        }

        ControllerAgentResponse(
            conversationalReply = reply,
            structuredAction = null,
            executionResult = null
        )
    }

    private fun detectEmotionalTone(text: String): EmotionalTone {
        val t = text.lowercase()
        return when {
            t.contains("nahi hoga") || t.contains("give up") || t.contains("ro dunga") || t.contains("dar lag raha") ||
            t.contains("bilkul nahi") || t.contains("stressed") || t.contains("tension") -> EmotionalTone.FRUSTRATED_OVERWHELMED

            t.contains("bahut piche") || t.contains("missed") || t.contains("kuch nahi padha") || t.contains("panic") ||
            t.contains("chhoot gaya") || t.contains("backlog") -> EmotionalTone.BEHIND_SCHEDULE

            t.contains("accha gaya") || t.contains("badhiya") || t.contains("confident") || t.contains("mast") ||
            t.contains("maza aaya") || t.contains("easy lag raha") || t.contains("top karunga") -> EmotionalTone.CONFIDENT_CELEBRATING

            t.contains("mann nahi") || t.contains("bore") || t.contains("alas") || t.contains("kal padhunga") ||
            t.contains("tired") || t.contains("neend") || t.contains("thak gaya") -> EmotionalTone.LOW_ENERGY_PROCRASTINATING

            else -> EmotionalTone.NEUTRAL
        }
    }

    private fun getEmotionalCoachingHeader(tone: EmotionalTone): String {
        return when (tone) {
            EmotionalTone.FRUSTRATED_OVERWHELMED ->
                "Arre, ruk 😭 Ek saath poori subject ko dekhoge to obviously heavy lagegi. Abhi ke liye bas 3 basic practice questions karte hain. Pehle momentum banate hain!\n\n"
            EmotionalTone.BEHIND_SCHEDULE ->
                "Gap hai, par bilkul panic mat karo. Pehle dekhte hain actual deficit kitna hai. Main tumhara remaining workload calculate karke roadmap ko bina burn-out ke adapt kar raha hoon.\n\n"
            EmotionalTone.CONFIDENT_CELEBRATING ->
                "Nice! Aaj ka output genuinely strong raha. Is momentum ko capture karke kal ka load intelligently adjust karte hain.\n\n"
            EmotionalTone.LOW_ENERGY_PROCRASTINATING ->
                "Normal hai, roz 100% motivation nahi rehta. Ek chhota 15-minute recall session karte hain bina kisi heavy stress ke. Bas 5 minute baitho.\n\n"
            EmotionalTone.NEUTRAL -> ""
        }
    }

    private fun buildActionResponseExplanation(
        intent: StudentIntent,
        action: StructuredAiAction,
        result: AiActionResult,
        daysLeft: Long
    ): String {
        val builder = StringBuilder()

        builder.append("⚡ FULL APP CONTROL ACTION EXECUTED:\n")
        builder.append("• Command Intent: ${intent.name.replace("_", " ")}\n")
        if (action.targetSubject.isNotBlank()) builder.append("• Target Subject: ${action.targetSubject}\n")
        if (action.targetChapter.isNotBlank()) builder.append("• Target Chapter: ${action.targetChapter}\n")
        if (action.hoursAvailable > 0) builder.append("• Study Availability: ${action.hoursAvailable} hours\n")
        if (action.questionCount > 0) builder.append("• Requested Question Count: ${action.questionCount}\n")

        builder.append("\nWHAT I CHANGED IN EXAM OS:\n")
        builder.append("• ${result.summaryMessage}\n")
        result.changesApplied.forEach { change ->
            builder.append("  - $change\n")
        }

        builder.append("\nWHAT HAPPENS NEXT:\n")
        builder.append("• ${result.nextActionGuidance.ifBlank { "Roadmap and app data have been recalculated automatically." }}\n")
        builder.append("• Target Exam Countdown: $daysLeft days remaining.")

        return builder.toString()
    }

    private fun generateGroundedChatResponse(message: String, examName: String, daysLeft: Long): String {
        val t = message.lowercase()
        return when {
            t.contains("quadratic") -> """
                [AI TEACHER • QUADRATIC EQUATIONS]
                For equation ax² + bx + c = 0:
                • Discriminant D = b² - 4ac
                • If D > 0: Two distinct real roots
                • If D = 0: Two equal real roots (x = -b / 2a)
                • If D < 0: No real roots (roots are complex)
                
                High-Yield Exam Tip: Always check whether the coefficient of x² can be zero before applying standard root formulas.
                
                Next Action: Try solving 5 quadratic root problems in your practice sets.
            """.trimIndent()

            t.contains("electricity") || t.contains("ohm") || t.contains("kirchhoff") -> """
                [AI TEACHER • ELECTRICITY & CIRCUITS]
                • Ohm's Law: V = I * R (holds when temperature and physical dimensions remain constant)
                • Series Resistors: R_eq = R₁ + R₂ + ... (Current is constant through all resistors)
                • Parallel Resistors: 1/R_eq = 1/R₁ + 1/R₂ + ... (Voltage is equal across branches)
                • Joule's Heating: H = I² * R * t
                
                Next Action: Check out the 40-question Science test in the Mock Tests section.
            """.trimIndent()

            else -> """
                [EXAM OS AGENT RESPONSE • ROOT APP ACCESS ACTIVE]
                Connected Exam: $examName ($daysLeft days remaining).
                
                You have full control over the app via this chat. Try commanding:
                • "Rebuild roadmap for 366 days"
                • "Start 45m focus session on Mathematics"
                • "Add subject Computer Science"
                • "Mark Quadratic Equations as completed"
                • "Create 50 questions mock test"
                • "Set my daily study target to 6 hours"
                • "Lock Day 1"
                • "Switch to JEE Main 2027"
            """.trimIndent()
        }
    }
}
