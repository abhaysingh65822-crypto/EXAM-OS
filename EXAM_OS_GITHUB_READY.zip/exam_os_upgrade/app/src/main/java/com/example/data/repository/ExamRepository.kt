package com.example.data.repository

import com.example.data.db.ExamChapterEntity
import com.example.data.db.ExamDao
import com.example.data.db.ExamProfileEntity
import com.example.data.db.ExamSubjectEntity
import com.example.data.db.ExamTopicEntity
import com.example.data.model.TopicStatus
import com.example.domain.DiscoveredExamData
import kotlinx.coroutines.flow.Flow

class ExamRepository(private val dao: ExamDao) {

    val activeProfileFlow: Flow<ExamProfileEntity?> = dao.getActiveExamProfileFlow()
    val allChaptersFlow: Flow<List<ExamChapterEntity>> = dao.getAllChaptersFlow()
    val allTopicsFlow: Flow<List<ExamTopicEntity>> = dao.getAllTopicsFlow()
    val weakTopicsFlow: Flow<List<ExamTopicEntity>> = dao.getWeakAndRevisionTopics()

    fun getSubjectsFlow(examId: Long): Flow<List<ExamSubjectEntity>> = dao.getSubjectsForExam(examId)
    fun getChaptersFlow(subjectId: Long): Flow<List<ExamChapterEntity>> = dao.getChaptersForSubject(subjectId)
    fun getTopicsFlow(chapterId: Long): Flow<List<ExamTopicEntity>> = dao.getTopicsForChapter(chapterId)

    suspend fun getActiveProfile(): ExamProfileEntity? = dao.getActiveExamProfile()

    suspend fun saveAutonomousExamSetup(discovered: DiscoveredExamData): Long {
        dao.clearAllProfiles()
        val profileId = dao.insertExamProfile(discovered.profile)

        val subjectEntitiesWithExamId = discovered.subjects.map { it.copy(examId = profileId) }
        val subjectIds = dao.insertSubjects(subjectEntitiesWithExamId)

        subjectEntitiesWithExamId.forEachIndexed { index, subject ->
            val subId = subjectIds.getOrNull(index) ?: return@forEachIndexed
            val chapters = discovered.chaptersMap[subject.name] ?: emptyList()
            val chapterEntitiesWithSubId = chapters.map { it.copy(subjectId = subId) }
            val chapterIds = dao.insertChapters(chapterEntitiesWithSubId)

            chapterEntitiesWithSubId.forEachIndexed { cIndex, chapter ->
                val chapId = chapterIds.getOrNull(cIndex) ?: return@forEachIndexed
                val topics = discovered.topicsMap[chapter.name] ?: emptyList()
                val topicEntitiesWithChapId = topics.map { it.copy(chapterId = chapId) }
                dao.insertTopics(topicEntitiesWithChapId)
            }
        }

        return profileId
    }

    suspend fun updateProfile(profile: ExamProfileEntity) {
        dao.updateExamProfile(profile)
    }

    suspend fun updateChapterMastery(chapterId: Long, newMastery: Int, status: TopicStatus) {
        val chapters = dao.getAllChapters()
        val chapter = chapters.find { it.id == chapterId }
        if (chapter != null) {
            dao.updateChapter(chapter.copy(masteryScore = newMastery, status = status))
        }
    }

    suspend fun updateTopicStatus(topic: ExamTopicEntity) {
        dao.updateTopic(topic)
    }

    suspend fun recalculateReadinessScore(): Int {
        val chapters = dao.getAllChapters()
        if (chapters.isEmpty()) return 10
        val avgMastery = chapters.map { it.masteryScore }.average()
        val activeProfile = dao.getActiveExamProfile()
        val computed = avgMastery.toInt().coerceIn(5, 99)
        if (activeProfile != null) {
            dao.updateExamProfile(activeProfile.copy(readinessScore = computed))
        }
        return computed
    }
}
