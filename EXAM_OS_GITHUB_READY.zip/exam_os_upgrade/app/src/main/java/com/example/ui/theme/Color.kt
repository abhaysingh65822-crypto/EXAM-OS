package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate950 = Color(0xFF070A12)
val Slate900 = Color(0xFF101522)
val Slate800 = Color(0xFF1A2233)
val Slate700 = Color(0xFF2A354B)
val Cyan400 = Color(0xFF22D3EE)
val Emerald400 = Color(0xFF34D399)
val Amber400 = Color(0xFFFBBF24)
val Rose400 = Color(0xFFFB7185)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

val AmberGold = Amber400
val ElectricBlue = Cyan400
val EmeraldNeon = Emerald400
val VioletPurple = Color(0xFFA78BFA)
