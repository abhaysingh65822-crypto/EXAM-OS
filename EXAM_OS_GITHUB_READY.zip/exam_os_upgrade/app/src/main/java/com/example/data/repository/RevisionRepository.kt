package com.example.data.repository

import com.example.data.db.ExamDao
import com.example.data.db.RevisionItemEntity
import kotlinx.coroutines.flow.Flow

class RevisionRepository(private val dao: ExamDao) {

    val pendingRevisionsFlow: Flow<List<RevisionItemEntity>> = dao.getPendingRevisionsFlow()

    fun getOverdueRevisionsFlow(): Flow<List<RevisionItemEntity>> = dao.getOverdueRevisionsFlow(System.currentTimeMillis())

    suspend fun scheduleInitialRevision(
        examId: Long,
        topicId: Long,
        topicName: String,
        subjectName: String,
        chapterName: String
    ): Long {
        val nextDayMs = System.currentTimeMillis() + (1 * 24 * 60 * 60 * 1000L)
        val item = RevisionItemEntity(
            examId = examId,
            topicId = topicId,
            topicName = topicName,
            subjectName = subjectName,
            chapterName = chapterName,
            currentIntervalDay = 1,
            nextRevisionEpochMs = nextDayMs,
            repetitionCount = 0,
            retentionScore = 70
        )
        return dao.insertRevisionItem(item)
    }

    suspend fun completeRevision(item: RevisionItemEntity, retentionQualityRating: Int) { // 1 = poor, 3 = good, 5 = perfect
        val nextIntervalDays = when {
            retentionQualityRating <= 2 -> 1 // Shorten interval on struggle
            item.currentIntervalDay == 1 -> 3
            item.currentIntervalDay == 3 -> 7
            item.currentIntervalDay == 7 -> 14
            item.currentIntervalDay == 14 -> 30
            else -> 45
        }

        val nextEpochMs = System.currentTimeMillis() + (nextIntervalDays * 24 * 60 * 60 * 1000L)
        val newRetention = when (retentionQualityRating) {
            1 -> 40
            2 -> 60
            3 -> 75
            4 -> 90
            else -> 100
        }

        val updated = item.copy(
            currentIntervalDay = nextIntervalDays,
            nextRevisionEpochMs = nextEpochMs,
            repetitionCount = item.repetitionCount + 1,
            retentionScore = newRetention,
            lastRevisedEpochMs = System.currentTimeMillis(),
            isCompleted = false // stays in the queue for the next interval
        )
        dao.updateRevisionItem(updated)
    }
}
