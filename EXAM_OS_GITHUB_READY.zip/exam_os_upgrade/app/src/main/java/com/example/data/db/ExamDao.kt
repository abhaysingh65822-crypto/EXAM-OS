package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDao {

    // --- Exam Profile ---
    @Query("SELECT * FROM exam_profiles ORDER BY id DESC LIMIT 1")
    fun getActiveExamProfileFlow(): Flow<ExamProfileEntity?>

    @Query("SELECT * FROM exam_profiles ORDER BY id DESC LIMIT 1")
    suspend fun getActiveExamProfile(): ExamProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamProfile(profile: ExamProfileEntity): Long

    @Update
    suspend fun updateExamProfile(profile: ExamProfileEntity)

    @Query("DELETE FROM exam_profiles")
    suspend fun clearAllProfiles()

    // --- Subjects ---
    @Query("SELECT * FROM exam_subjects WHERE examId = :examId ORDER BY orderIndex ASC")
    fun getSubjectsForExam(examId: Long): Flow<List<ExamSubjectEntity>>

    @Query("SELECT * FROM exam_subjects WHERE examId = :examId ORDER BY orderIndex ASC")
    suspend fun getSubjectsList(examId: Long): List<ExamSubjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<ExamSubjectEntity>): List<Long>

    // --- Chapters ---
    @Query("SELECT * FROM exam_chapters WHERE subjectId = :subjectId ORDER BY orderIndex ASC")
    fun getChaptersForSubject(subjectId: Long): Flow<List<ExamChapterEntity>>

    @Query("SELECT * FROM exam_chapters ORDER BY masteryScore ASC")
    fun getAllChaptersFlow(): Flow<List<ExamChapterEntity>>

    @Query("SELECT * FROM exam_chapters")
    suspend fun getAllChapters(): List<ExamChapterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ExamChapterEntity>): List<Long>

    @Update
    suspend fun updateChapter(chapter: ExamChapterEntity)

    // --- Topics ---
    @Query("SELECT * FROM exam_topics WHERE chapterId = :chapterId")
    fun getTopicsForChapter(chapterId: Long): Flow<List<ExamTopicEntity>>

    @Query("SELECT * FROM exam_topics")
    fun getAllTopicsFlow(): Flow<List<ExamTopicEntity>>

    @Query("SELECT * FROM exam_topics WHERE status = 'NEEDS_REVISION' OR status = 'WEAK'")
    fun getWeakAndRevisionTopics(): Flow<List<ExamTopicEntity>>

    @Query("SELECT * FROM exam_topics")
    suspend fun getAllTopics(): List<ExamTopicEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(topics: List<ExamTopicEntity>)

    @Update
    suspend fun updateTopic(topic: ExamTopicEntity)

    // --- Study Sessions ---
    @Query("SELECT * FROM study_sessions ORDER BY timestampEpochMs DESC")
    fun getAllStudySessionsFlow(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions WHERE timestampEpochMs >= :sinceEpochMs ORDER BY timestampEpochMs DESC")
    fun getStudySessionsSince(sinceEpochMs: Long): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions")
    suspend fun getAllStudySessions(): List<StudySessionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySession(session: StudySessionEntity): Long

    // --- Daily Plan Tasks ---
    @Query("SELECT * FROM daily_plan_tasks WHERE dateString = :dateString ORDER BY priorityOrder ASC")
    fun getTasksForDateFlow(dateString: String): Flow<List<DailyPlanTaskEntity>>

    @Query("SELECT * FROM daily_plan_tasks WHERE isCompleted = 0 ORDER BY priorityOrder ASC")
    fun getPendingTasksFlow(): Flow<List<DailyPlanTaskEntity>>

    @Query("SELECT * FROM daily_plan_tasks WHERE dateString = :dateString")
    suspend fun getTasksForDate(dateString: String): List<DailyPlanTaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyTasks(tasks: List<DailyPlanTaskEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyTask(task: DailyPlanTaskEntity): Long

    @Update
    suspend fun updateDailyTask(task: DailyPlanTaskEntity)

    @Delete
    suspend fun deleteDailyTask(task: DailyPlanTaskEntity)

    // --- Revision Queue ---
    @Query("SELECT * FROM revision_items WHERE isCompleted = 0 ORDER BY nextRevisionEpochMs ASC")
    fun getPendingRevisionsFlow(): Flow<List<RevisionItemEntity>>

    @Query("SELECT * FROM revision_items WHERE nextRevisionEpochMs <= :nowEpochMs AND isCompleted = 0")
    fun getOverdueRevisionsFlow(nowEpochMs: Long): Flow<List<RevisionItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevisionItem(item: RevisionItemEntity): Long

    @Update
    suspend fun updateRevisionItem(item: RevisionItemEntity)

    // --- Error Logs ---
    @Query("SELECT * FROM error_logs ORDER BY timestampEpochMs DESC")
    fun getAllErrorsFlow(): Flow<List<ErrorLogEntity>>

    @Query("SELECT * FROM error_logs WHERE isRepaired = 0 ORDER BY timestampEpochMs DESC")
    fun getUnrepairedErrorsFlow(): Flow<List<ErrorLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertErrorLog(error: ErrorLogEntity): Long

    @Update
    suspend fun updateErrorLog(error: ErrorLogEntity)

    // --- Tests & Mock Exams ---
    @Query("SELECT * FROM tests ORDER BY timestampEpochMs DESC")
    fun getAllTestsFlow(): Flow<List<TestModelEntity>>

    @Query("SELECT * FROM tests WHERE id = :testId")
    suspend fun getTestById(testId: Long): TestModelEntity?

    @Query("SELECT * FROM test_questions WHERE testId = :testId ORDER BY questionNumber ASC")
    fun getQuestionsForTestFlow(testId: Long): Flow<List<TestQuestionEntity>>

    @Query("SELECT * FROM test_questions WHERE testId = :testId ORDER BY questionNumber ASC")
    suspend fun getQuestionsForTest(testId: Long): List<TestQuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTest(test: TestModelEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTestQuestions(questions: List<TestQuestionEntity>)

    @Update
    suspend fun updateTest(test: TestModelEntity)

    @Update
    suspend fun updateTestQuestion(question: TestQuestionEntity)

    // --- Focus & Distraction Blocking ---
    @Query("SELECT * FROM blocked_apps")
    fun getBlockedAppsFlow(): Flow<List<BlockedAppEntity>>

    @Query("SELECT * FROM blocked_apps WHERE isBlocked = 1")
    suspend fun getActiveBlockedApps(): List<BlockedAppEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlockedApps(apps: List<BlockedAppEntity>)

    @Update
    suspend fun updateBlockedApp(app: BlockedAppEntity)

    @Query("SELECT * FROM focus_sessions ORDER BY timestampEpochMs DESC")
    fun getAllFocusSessionsFlow(): Flow<List<FocusSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFocusSession(session: FocusSessionEntity): Long

    // --- AI Audit Logs ---
    @Query("SELECT * FROM ai_audit_logs ORDER BY timestampEpochMs DESC")
    fun getAiAuditLogsFlow(): Flow<List<AiAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAiAuditLog(log: AiAuditLogEntity): Long

    // --- Question Bank ---
    @Query("SELECT * FROM question_bank ORDER BY id DESC")
    fun getAllQuestionBankFlow(): Flow<List<QuestionBankEntity>>

    @Query("SELECT * FROM question_bank ORDER BY id DESC")
    suspend fun getAllQuestionBankList(): List<QuestionBankEntity>

    @Query("SELECT * FROM question_bank WHERE subjectName = :subjectName")
    suspend fun getQuestionsForSubject(subjectName: String): List<QuestionBankEntity>

    @Query("SELECT * FROM question_bank WHERE chapterName = :chapterName")
    suspend fun getQuestionsForChapter(chapterName: String): List<QuestionBankEntity>

    @Query("SELECT fingerprint FROM question_bank")
    suspend fun getAllQuestionFingerprints(): List<String>

    @Query("SELECT COUNT(*) FROM question_bank")
    suspend fun getQuestionBankCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestionBankItem(item: QuestionBankEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestionsBankList(items: List<QuestionBankEntity>): List<Long>

    // --- Roadmap Versions ---
    @Query("SELECT * FROM roadmap_versions ORDER BY versionNumber DESC LIMIT 1")
    fun getLatestRoadmapVersionFlow(): Flow<RoadmapPlanVersionEntity?>

    @Query("SELECT * FROM roadmap_versions ORDER BY versionNumber DESC LIMIT 1")
    suspend fun getLatestRoadmapVersion(): RoadmapPlanVersionEntity?

    @Query("SELECT * FROM roadmap_versions ORDER BY versionNumber DESC")
    fun getAllRoadmapVersionsFlow(): Flow<List<RoadmapPlanVersionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoadmapVersion(version: RoadmapPlanVersionEntity): Long

    // --- Student Availability ---
    @Query("SELECT * FROM student_availability ORDER BY id DESC LIMIT 1")
    fun getAvailabilityFlow(): Flow<StudentAvailabilityEntity?>

    @Query("SELECT * FROM student_availability ORDER BY id DESC LIMIT 1")
    suspend fun getAvailability(): StudentAvailabilityEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAvailability(availability: StudentAvailabilityEntity): Long

    // --- AI Action Audits ---
    @Query("SELECT * FROM ai_action_audits ORDER BY timestampEpochMs DESC LIMIT 50")
    fun getRecentAiActionAuditsFlow(): Flow<List<AiActionAuditEntity>>

    @Query("SELECT * FROM ai_action_audits ORDER BY id DESC LIMIT 1")
    suspend fun getLatestAiActionAudit(): AiActionAuditEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAiActionAudit(audit: AiActionAuditEntity): Long

    @Update
    suspend fun updateAiActionAudit(audit: AiActionAuditEntity)

    // --- Granular Syllabus Mutations ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSingleSubject(subject: ExamSubjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSingleChapter(chapter: ExamChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSingleTopic(topic: ExamTopicEntity): Long

    @Query("DELETE FROM exam_subjects WHERE id = :subjectId")
    suspend fun deleteSubjectById(subjectId: Long)

    @Query("DELETE FROM exam_chapters WHERE id = :chapterId")
    suspend fun deleteChapterById(chapterId: Long)

    @Query("DELETE FROM exam_topics WHERE id = :topicId")
    suspend fun deleteTopicById(topicId: Long)

    @Query("DELETE FROM exam_subjects WHERE examId = :examId")
    suspend fun clearSubjectsForExam(examId: Long)

    @Query("DELETE FROM exam_chapters WHERE subjectId = :subjectId")
    suspend fun clearChaptersForSubject(subjectId: Long)

    @Query("DELETE FROM exam_topics WHERE chapterId = :chapterId")
    suspend fun clearTopicsForChapter(chapterId: Long)
}

