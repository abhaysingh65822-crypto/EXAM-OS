package com.example.data.api

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.security.SecureKeyStore
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

class GeminiApiClient(private val context: Context) {

    private val secureKeyStore = SecureKeyStore(context)

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            // Never log API-bearing request URLs in release builds.
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        })
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val service = retrofit.create(GeminiApiService::class.java)

    fun getEffectiveApiKey(customKey: String? = null): String {
        if (!customKey.isNullOrBlank()) return customKey.trim()
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (!buildKey.isNullOrBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey.trim()
        }
        val savedKey = secureKeyStore.get("gemini_api_key")
        if (!savedKey.isNullOrBlank()) return savedKey.trim()
        // One-time migration from the older plaintext preference used by v1.
        val legacyPrefs = context.getSharedPreferences("exam_os_prefs", Context.MODE_PRIVATE)
        val legacy = legacyPrefs.getString("user_gemini_api_key", null)
        if (!legacy.isNullOrBlank()) {
            secureKeyStore.put("gemini_api_key", legacy.trim())
            legacyPrefs.edit().remove("user_gemini_api_key").apply()
            return legacy.trim()
        }
        return ""
    }

    suspend fun generate(
        prompt: String,
        systemInstruction: String? = null,
        modelName: String = "gemini-3.5-flash",
        useSearchGrounding: Boolean = false,
        enableHighThinking: Boolean = false,
        chatHistory: List<GeminiContent> = emptyList(),
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey(customApiKey)
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured. Add your API key in Settings or AI Studio Secrets.")
            )
        }

        val contents = mutableListOf<GeminiContent>()
        if (chatHistory.isNotEmpty()) {
            contents.addAll(chatHistory)
        }
        contents.add(GeminiContent(role = "user", parts = listOf(GeminiPart(text = prompt))))

        val systemContent = systemInstruction?.let {
            GeminiContent(role = "system", parts = listOf(GeminiPart(text = it)))
        }

        val thinkingConfig = if (enableHighThinking) {
            GeminiThinkingConfig(thinkingLevel = "HIGH")
        } else null

        val generationConfig = GeminiGenerationConfig(
            temperature = if (enableHighThinking) 1.0f else 0.4f,
            thinkingConfig = thinkingConfig
        )

        val tools = if (useSearchGrounding) {
            listOf(mapOf("googleSearch" to emptyMap<String, Any>()))
        } else null

        val request = GeminiRequest(
            contents = contents,
            systemInstruction = systemContent,
            generationConfig = generationConfig,
            tools = tools
        )

        try {
            val response = service.generateContent(model = modelName, apiKey = apiKey, request = request)
            val candidate = response.candidates?.firstOrNull()
            val candidateText = candidate?.content?.parts?.firstOrNull()?.text
            if (!candidateText.isNullOrBlank()) {
                val queries = candidate.groundingMetadata?.webSearchQueries
                val textWithGrounding = if (!queries.isNullOrEmpty()) {
                    "$candidateText\n\n[🔍 Grounded with Google Search: ${queries.joinToString(", ")}]"
                } else {
                    candidateText
                }
                Result.success(textWithGrounding.trim())
            } else {
                val err = response.error?.message ?: "Empty response received from AI model"
                Result.failure(Exception(err))
            }
        } catch (e: retrofit2.HttpException) {
            if (e.code() == 429) {
                Log.w("GeminiApiClient", "Rate limit hit (HTTP 429). Attempting fallback...")
                if (useSearchGrounding) {
                    try {
                        val fallbackRequest = request.copy(tools = null)
                        val fallbackResponse = service.generateContent(model = modelName, apiKey = apiKey, request = fallbackRequest)
                        val fallbackText = fallbackResponse.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        if (!fallbackText.isNullOrBlank()) {
                            return@withContext Result.success(fallbackText.trim())
                        }
                    } catch (fallbackEx: Exception) {
                        Log.w("GeminiApiClient", "Direct fallback also rate limited (HTTP 429).")
                    }
                }
                Result.failure(Exception("AI provider rate limited (HTTP 429). Using verified grounded knowledge base."))
            } else {
                Log.w("GeminiApiClient", "HTTP ${e.code()} from Gemini API: ${e.message()}")
                Result.failure(e)
            }
        } catch (e: Exception) {
            Log.w("GeminiApiClient", "Generation exception: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun generateWithImage(
        prompt: String,
        imageBytes: ByteArray,
        mimeType: String = "image/jpeg",
        modelName: String = "gemini-3.5-flash",
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey(customApiKey)
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured. Add your API key in Settings or AI Studio Secrets to enable vision analysis.")
            )
        }

        val base64Image = android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP)
        val contents = listOf(
            GeminiContent(
                role = "user",
                parts = listOf(
                    GeminiPart(text = prompt),
                    GeminiPart(inlineData = GeminiInlineData(mimeType = mimeType, data = base64Image))
                )
            )
        )

        val request = GeminiRequest(
            contents = contents,
            generationConfig = GeminiGenerationConfig(temperature = 0.2f)
        )

        try {
            val response = service.generateContent(model = modelName, apiKey = apiKey, request = request)
            val candidateText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!candidateText.isNullOrBlank()) {
                Result.success(candidateText.trim())
            } else {
                val err = response.error?.message ?: "No response received from vision model"
                Result.failure(Exception(err))
            }
        } catch (e: retrofit2.HttpException) {
            if (e.code() == 429) {
                Log.w("GeminiApiClient", "Vision analysis rate limit hit (HTTP 429). Using offline analyzer.")
                Result.failure(Exception("Rate limited (HTTP 429)"))
            } else {
                Log.w("GeminiApiClient", "Vision analysis HTTP ${e.code()}: ${e.message()}")
                Result.failure(e)
            }
        } catch (e: Exception) {
            Log.w("GeminiApiClient", "Vision analysis error: ${e.message}")
            Result.failure(e)
        }
    }
}
