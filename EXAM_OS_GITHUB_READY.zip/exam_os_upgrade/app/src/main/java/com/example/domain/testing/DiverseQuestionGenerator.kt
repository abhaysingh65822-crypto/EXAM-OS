package com.example.domain.testing

import com.example.data.db.QuestionBankEntity
import com.example.data.db.TestQuestionEntity
import java.security.MessageDigest
import java.util.Locale

object DiverseQuestionGenerator {

    fun generateDiverseQuestionSet(
        examName: String,
        subjectName: String,
        chapterName: String?,
        requestedCount: Int,
        existingFingerprints: Set<String>
    ): List<QuestionBankEntity> {
        val safeCount = requestedCount.coerceIn(5, 100)
        val questions = mutableListOf<QuestionBankEntity>()
        val seenFingerprints = existingFingerprints.toMutableSet()

        // Curated master archetypes across Science, Mathematics, Physics, Chemistry, Biology & Aptitude
        val templates = getCuratedQuestionPool(examName, subjectName, chapterName)

        var cycleIndex = 0
        var attempts = 0
        while (questions.size < safeCount && attempts < safeCount * 4) {
            attempts++
            val template = templates[cycleIndex % templates.size]
            cycleIndex++

            // Generate parameter variant for numericals or different question styles
            val variant = createQuestionVariant(template, attempts)
            val fingerprint = computeFingerprint(variant.questionText, variant.correctOption)

            if (!seenFingerprints.contains(fingerprint)) {
                seenFingerprints.add(fingerprint)
                questions.add(
                    variant.copy(
                        fingerprint = fingerprint,
                        examName = examName,
                        subjectName = if (subjectName.isNotBlank()) subjectName else variant.subjectName
                    )
                )
            }
        }

        return questions
    }

    fun computeFingerprint(questionText: String, correctOption: String): String {
        val normalized = questionText.lowercase(Locale.getDefault())
            .replace(Regex("[^a-z0-9]"), "") + correctOption.uppercase()
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(normalized.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun createQuestionVariant(base: QuestionBankEntity, variantNum: Int): QuestionBankEntity {
        // Vary numerical constants or question phrasing smoothly if needed
        if (base.questionType == "NUMERICAL") {
            val factor = (variantNum % 4) + 1
            if (base.questionText.contains("wire of resistance") || base.questionText.contains("resistance")) {
                val newR = 2 * factor
                return base.copy(
                    questionText = "A uniform metallic wire of resistance ${newR} Ω is stretched to ${factor + 1} times its original length. What is its new resistance?",
                    optionA = "${newR * (factor + 1)} Ω",
                    optionB = "${newR * (factor + 1) * (factor + 1)} Ω",
                    optionC = "${newR} Ω",
                    optionD = "${newR / 2} Ω",
                    correctOption = "B",
                    explanation = "Stretching length by n times reduces cross-section area to A/n. New resistance R' = n² * R. Here R' = ${factor + 1}² * ${newR} = ${newR * (factor + 1) * (factor + 1)} Ω."
                )
            }
        }
        return base
    }

    private fun getCuratedQuestionPool(
        examName: String,
        subject: String,
        chapter: String?
    ): List<QuestionBankEntity> {
        val list = mutableListOf<QuestionBankEntity>()

        // 1. Science / Physics - Electricity & Circuits
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Electricity",
                topicName = "Ohm's Law & Resistance",
                questionText = "A cylindrical conductor of length L and uniform cross-section area A has resistance R. Another conductor of length 2.5L and resistance 0.5R of the same material has area of cross-section:",
                optionA = "5 A",
                optionB = "2.5 A",
                optionC = "0.5 A",
                optionD = "1.25 A",
                correctOption = "A",
                explanation = "R = ρ * L / A. For the second wire: 0.5R = ρ * (2.5L) / A'. Dividing: 0.5 = 2.5 * (A / A') => A' = (2.5 / 0.5) A = 5A.",
                difficulty = "MEDIUM",
                questionType = "NUMERICAL",
                sourceType = "PYQ_STYLE",
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Electricity",
                topicName = "Joule's Heating & Power",
                questionText = "Two electric bulbs rated 60 W, 220 V and 100 W, 220 V are connected in parallel across a 220 V mains supply. Which bulb draws more current?",
                optionA = "The 60 W bulb",
                optionB = "The 100 W bulb",
                optionC = "Both draw equal current",
                optionD = "Cannot be determined without resistance values",
                correctOption = "B",
                explanation = "In parallel, voltage V is constant (220 V). Power P = V * I, so I = P / V. The 100 W bulb draws I = 100/220 = 0.45 A, whereas the 60 W bulb draws only 0.27 A.",
                difficulty = "EASY",
                questionType = "CONCEPTUAL",
                sourceType = "AI_GENERATED"
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Electricity",
                topicName = "Magnetic Effects of Electric Current",
                questionText = "Assertion (A): A compass needle gets deflected when placed near a current-carrying wire.\nReason (R): An electric current through a metallic conductor produces a magnetic field around it.",
                optionA = "Both (A) and (R) are true and (R) is the correct explanation of (A)",
                optionB = "Both (A) and (R) are true but (R) is not the correct explanation of (A)",
                optionC = "(A) is true but (R) is false",
                optionD = "(A) is false but (R) is true",
                correctOption = "A",
                explanation = "Oersted discovered that an electric current produces a magnetic field in the surrounding space, which exerts torque on the magnetic dipole needle of the compass.",
                difficulty = "MEDIUM",
                questionType = "ASSERTION_REASON",
                sourceType = "PYQ_STYLE",
            )
        )

        // 2. Science / Chemistry - Chemical Reactions & Equations
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Chemical Reactions and Equations",
                topicName = "Types of Reactions & Redox",
                questionText = "In the reaction: CuO + H₂ → Cu + H₂O, which substance acts as the reducing agent?",
                optionA = "CuO",
                optionB = "H₂",
                optionC = "Cu",
                optionD = "H₂O",
                correctOption = "B",
                explanation = "H₂ gains oxygen to form H₂O (it is oxidised). The substance that undergoes oxidation acts as the reducing agent.",
                difficulty = "EASY",
                questionType = "CONCEPTUAL",
                sourceType = "AI_GENERATED"
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Chemical Reactions and Equations",
                topicName = "Balancing Equations",
                questionText = "When Lead Nitrate powder is heated in a dry boiling tube, brown fumes are evolved. The brown gas is:",
                optionA = "Nitrogen monoxide (NO)",
                optionB = "Nitrogen dioxide (NO₂)",
                optionC = "Nitrogen pentoxide (N₂O₅)",
                optionD = "Nitrous oxide (N₂O)",
                correctOption = "B",
                explanation = "2Pb(NO₃)₂ (s) → 2PbO (s) + 4NO₂ (g) + O₂ (g). NO₂ gas is reddish-brown with a pungent smell.",
                difficulty = "MEDIUM",
                questionType = "APPLICATION",
                sourceType = "PYQ_STYLE",
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Acids, Bases and Salts",
                topicName = "pH Scale & Neutralisation",
                questionText = "Tooth enamel is the hardest substance in the human body. It begins to corrode when the pH of the mouth falls below:",
                optionA = "7.0",
                optionB = "6.5",
                optionC = "5.5",
                optionD = "4.0",
                correctOption = "C",
                explanation = "Tooth enamel is made of calcium hydroxyapatite. When bacteria degrade food sugars in the mouth, acid produced lowers the pH below 5.5, leading to enamel dissolution.",
                difficulty = "EASY",
                questionType = "CONCEPTUAL",
                sourceType = "AI_GENERATED"
            )
        )

        // 3. Mathematics - Quadratic Equations & Arithmetic Progressions
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Mathematics",
                chapterName = "Quadratic Equations",
                topicName = "Nature of Roots",
                questionText = "For what value of k does the quadratic equation 2x² - kx + k = 0 have real and equal roots?",
                optionA = "k = 0 only",
                optionB = "k = 8 only",
                optionC = "k = 0 or k = 8",
                optionD = "k = 4 only",
                correctOption = "C",
                explanation = "Equal roots require discriminant D = b² - 4ac = 0. (-k)² - 4(2)(k) = 0 => k² - 8k = 0 => k(k - 8) = 0 => k = 0 or k = 8.",
                difficulty = "MEDIUM",
                questionType = "NUMERICAL",
                sourceType = "PYQ_STYLE",
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Mathematics",
                chapterName = "Quadratic Equations",
                topicName = "Solutions & Factorisation",
                questionText = "If one root of the quadratic equation 3x² + px + 4 = 0 is 2/3, then the value of p is:",
                optionA = "-8",
                optionB = "8",
                optionC = "-6",
                optionD = "6",
                correctOption = "A",
                explanation = "Substitute x = 2/3: 3(4/9) + p(2/3) + 4 = 0 => 4/3 + (2p/3) + 12/3 = 0 => 16 + 2p = 0 => p = -8.",
                difficulty = "MEDIUM",
                questionType = "NUMERICAL",
                sourceType = "PYQ_STYLE",
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Mathematics",
                chapterName = "Arithmetic Progressions",
                topicName = "nth Term & Sum",
                questionText = "The 11th term from the last term of the AP: 10, 7, 4, ..., -62 is:",
                optionA = "-32",
                optionB = "-16",
                optionC = "-20",
                optionD = "16",
                correctOption = "A",
                explanation = "Reversing the AP from the end: first term a' = -62, common difference d' = +3. 11th term l₁₁ = a' + 10d' = -62 + 10(3) = -32.",
                difficulty = "HARD",
                questionType = "LOGICAL",
                sourceType = "AI_GENERATED"
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Mathematics",
                chapterName = "Introduction to Trigonometry",
                topicName = "Trigonometric Identities",
                questionText = "If sin θ + cos θ = √2 cos θ, then the exact value of (cos θ - sin θ) is:",
                optionA = "√2 sin θ",
                optionB = "-√2 sin θ",
                optionC = "√2 cos θ",
                optionD = "1 / √2",
                correctOption = "A",
                explanation = "Squaring: (sin θ + cos θ)² = 2 cos² θ => 1 + 2 sin θ cos θ = 2 cos² θ => 2 sin θ cos θ = 2 cos² θ - 1 = cos² θ - sin² θ = (cos θ - sin θ)(cos θ + sin θ). Substituting gives (cos θ - sin θ) = √2 sin θ.",
                difficulty = "HARD",
                questionType = "APPLICATION",
                sourceType = "PYQ_STYLE",
            )
        )

        // 4. Life Sciences / Biology - Life Processes & Genetics
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Life Processes",
                topicName = "Nutrition & Respiration",
                questionText = "During vigorous anaerobic exercise in human muscle cells, the accumulation of which compound causes muscle fatigue and cramps?",
                optionA = "Ethanol",
                optionB = "Lactic acid",
                optionC = "Pyruvic acid",
                optionD = "Carbon dioxide only",
                correctOption = "B",
                explanation = "In insufficient oxygen, pyruvate is converted into lactic acid (3-carbon molecule) via anaerobic fermentation, causing painful muscle cramps.",
                difficulty = "EASY",
                questionType = "CONCEPTUAL",
                sourceType = "AI_GENERATED"
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Life Processes",
                topicName = "Excretion & Nephron",
                questionText = "The filtration units of kidneys are called nephrons. Initial filtrate collected in Bowman's capsule does NOT normally contain:",
                optionA = "Glucose",
                optionB = "Amino acids",
                optionC = "Large blood proteins & cells",
                optionD = "Urea and uric acid",
                correctOption = "C",
                explanation = "Glomerular filtration slits are too fine for large plasma proteins and blood cells (erythrocytes/leukocytes) to pass into Bowman's capsule.",
                difficulty = "MEDIUM",
                questionType = "CONCEPTUAL",
                sourceType = "AI_GENERATED"
            )
        )
        list.add(
            QuestionBankEntity(
                examName = examName,
                subjectName = "Science",
                chapterName = "Light – Reflection and Refraction",
                topicName = "Lenses & Mirrors",
                questionText = "A convex lens of focal length 20 cm produces a real, inverted image of the same size as the object. The distance of the object from the optical centre is:",
                optionA = "20 cm",
                optionB = "40 cm",
                optionC = "10 cm",
                optionD = "30 cm",
                correctOption = "B",
                explanation = "A real, inverted image of the same size is formed when the object is placed at 2F₁ (twice the focal length). Here 2f = 2 * 20 = 40 cm.",
                difficulty = "MEDIUM",
                questionType = "NUMERICAL",
                sourceType = "PYQ_STYLE",
            )
        )

        return list
    }
}
