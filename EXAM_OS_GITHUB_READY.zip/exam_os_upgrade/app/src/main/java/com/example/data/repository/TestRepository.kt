package com.example.data.repository

import com.example.data.db.ExamDao
import com.example.data.db.TestModelEntity
import com.example.data.db.TestQuestionEntity
import kotlinx.coroutines.flow.Flow

class TestRepository(private val dao: ExamDao) {

    val allTestsFlow: Flow<List<TestModelEntity>> = dao.getAllTestsFlow()

    fun getQuestionsForTestFlow(testId: Long): Flow<List<TestQuestionEntity>> = dao.getQuestionsForTestFlow(testId)

    suspend fun getTestById(testId: Long): TestModelEntity? = dao.getTestById(testId)
    suspend fun getQuestionsForTest(testId: Long): List<TestQuestionEntity> = dao.getQuestionsForTest(testId)

    suspend fun createDiagnosticTest(examId: Long, examName: String): Long {
        val test = TestModelEntity(
            examId = examId,
            title = "$examName — Baseline Diagnostic Benchmark",
            testType = "DIAGNOSTIC",
            durationMinutes = 20,
            totalMarks = 20,
            totalQuestions = 5,
            passingMarks = 10,
            isCompleted = false
        )
        val testId = dao.insertTest(test)

        val questions = listOf(
            TestQuestionEntity(
                testId = testId,
                questionNumber = 1,
                questionText = "If a wire of resistance R is stretched uniformly to twice its original length, its new electrical resistance becomes:",
                optionA = "2 R",
                optionB = "4 R",
                optionC = "R / 2",
                optionD = "R / 4",
                correctOption = "B",
                explanation = "Volume remains constant (V = A * L). Stretching to 2L halves the cross-sectional area (A' = A/2). Since R = ρ * (L/A), new resistance R' = ρ * (2L / (A/2)) = 4 * R.",
                subjectName = "Physics / Science",
                chapterName = "Current Electricity & Circuits",
                difficulty = "MEDIUM",
                positiveMarks = 4f,
                negativeMarks = 1f
            ),
            TestQuestionEntity(
                testId = testId,
                questionNumber = 2,
                questionText = "For quadratic equation ax² + bx + c = 0, real and distinct roots exist if and only if the discriminant (b² - 4ac) satisfies:",
                optionA = "b² - 4ac < 0",
                optionB = "b² - 4ac = 0",
                optionC = "b² - 4ac > 0",
                optionD = "b² - 4ac ≤ 0",
                correctOption = "C",
                explanation = "When discriminant D > 0, the square root produces two distinct non-zero real offsets resulting in two distinct real roots.",
                subjectName = "Mathematics",
                chapterName = "Quadratic Equations",
                difficulty = "EASY",
                positiveMarks = 4f,
                negativeMarks = 1f
            ),
            TestQuestionEntity(
                testId = testId,
                questionNumber = 3,
                questionText = "Which of the following bonds has the highest percentage of ionic character according to electronegativity difference?",
                optionA = "C - H",
                optionB = "H - Cl",
                optionC = "Na - F",
                optionD = "C - C",
                correctOption = "C",
                explanation = "Fluorine has the highest electronegativity (4.0) and Sodium has low electronegativity (0.9), creating the largest dipole difference (>2.1) and maximum ionic character.",
                subjectName = "Chemistry",
                chapterName = "Chemical Bonding",
                difficulty = "MEDIUM",
                positiveMarks = 4f,
                negativeMarks = 1f
            ),
            TestQuestionEntity(
                testId = testId,
                questionNumber = 4,
                questionText = "In a biological cell, the organelle primarily responsible for cellular respiration and ATP generation is:",
                optionA = "Ribosome",
                optionB = "Mitochondria",
                optionC = "Golgi Apparatus",
                optionD = "Endoplasmic Reticulum",
                correctOption = "B",
                explanation = "Mitochondria carry out the Krebs cycle and oxidative phosphorylation on the cristae inner membrane to synthesize ATP.",
                subjectName = "Biology / Life Science",
                chapterName = "Life Processes & Cell Structure",
                difficulty = "EASY",
                positiveMarks = 4f,
                negativeMarks = 1f
            ),
            TestQuestionEntity(
                testId = testId,
                questionNumber = 5,
                questionText = "If log₂(x) + log₂(x - 2) = 3, the valid real value of x is:",
                optionA = "4",
                optionB = "-2",
                optionC = "3",
                optionD = "5",
                correctOption = "A",
                explanation = "log₂(x(x - 2)) = 3 => x² - 2x = 2³ = 8 => x² - 2x - 8 = 0 => (x - 4)(x + 2) = 0. Since log argument must be positive (x > 2), x = 4.",
                subjectName = "Mathematics",
                chapterName = "Logarithms & Algebra",
                difficulty = "HARD",
                positiveMarks = 4f,
                negativeMarks = 1f
            )
        )
        dao.insertTestQuestions(questions)
        return testId
    }

    suspend fun submitTestAnswers(
        testId: Long,
        answers: Map<Long, String> // questionId -> selectedOption
    ): TestModelEntity? {
        val test = dao.getTestById(testId) ?: return null
        val questions = dao.getQuestionsForTest(testId)

        var correctCount = 0
        var wrongCount = 0
        var totalScore = 0f

        questions.forEach { q ->
            val userChoice = answers[q.id]
            val isCorrect = userChoice != null && userChoice.equals(q.correctOption, ignoreCase = true)
            if (userChoice != null) {
                if (isCorrect) {
                    correctCount++
                    totalScore += q.positiveMarks
                } else {
                    wrongCount++
                    totalScore -= q.negativeMarks
                }
            }
            dao.updateTestQuestion(q.copy(selectedOption = userChoice, isCorrect = isCorrect))
        }

        val accuracy = if (correctCount + wrongCount > 0) {
            (correctCount.toFloat() / (correctCount + wrongCount)) * 100f
        } else 0f

        val updatedTest = test.copy(
            isCompleted = true,
            scoreObtained = totalScore.coerceAtLeast(0f),
            accuracyPct = accuracy,
            aiDiagnosticReport = "Diagnostic completed: $correctCount correct, $wrongCount incorrect. Baseline accuracy: ${"%.1f".format(accuracy)}%."
        )
        dao.updateTest(updatedTest)
        return updatedTest
    }
}
