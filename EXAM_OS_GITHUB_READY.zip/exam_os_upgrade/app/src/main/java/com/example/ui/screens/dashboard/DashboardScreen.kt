package com.example.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.domain.CountdownStrategyEngine
import com.example.domain.roadmap.DynamicRoadmapEngine
import com.example.ui.components.RoadmapTimelineCard
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun DashboardScreen(
    viewModel: ExamOsViewModel,
    onNavigateToSyllabus: () -> Unit,
    onNavigateToFocus: () -> Unit,
    onNavigateToTests: () -> Unit,
    onNavigateToErrors: () -> Unit,
    onNavigateToAi: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val profile by viewModel.activeProfile.collectAsState()
    val tasks by viewModel.todayTasks.collectAsState()
    val roadmap by viewModel.roadmapVersion.collectAsState()
    val reply by viewModel.aiReply.collectAsState()
    val roadmapPlans = remember(roadmap?.id, roadmap?.planDaysJson) { roadmap?.let(DynamicRoadmapEngine::parseRoadmapFromVersion).orEmpty() }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("EXAM OS", style = MaterialTheme.typography.headlineMedium)
            profile?.let {
                val days = CountdownStrategyEngine.getDaysRemaining(it.targetExamDateEpochMs)
                Text(it.examName, style = MaterialTheme.typography.titleLarge)
                Text("$days days left • Readiness ${it.readinessScore}%")
            }
        }
        item { Button(onClick = onNavigateToAi, Modifier.fillMaxWidth()) { Text("🧠 Ask / Control Exam OS") } }
        item { OutlinedButton(onClick = { viewModel.rebuildRoadmap() }, Modifier.fillMaxWidth()) { Text("🔄 Rebuild adaptive roadmap") } }
        item { Text("TODAY", style = MaterialTheme.typography.titleLarge) }
        items(tasks) { task ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Checkbox(task.isCompleted, { viewModel.toggleTask(task) })
                    Column(Modifier.weight(1f)) {
                        Text(task.expectedOutcome, style = MaterialTheme.typography.titleMedium)
                        Text("${task.subjectName} • ${task.chapterName} • ${task.durationMinutes} min")
                        Text(task.reason, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item { Text("ROADMAP", style = MaterialTheme.typography.titleLarge) }
        roadmap?.let { v ->
            item { Text("Version ${v.versionNumber} • ${"%.1f".format(v.totalHours)}h planned • ${v.reason}") }
        }
        items(roadmapPlans.take(14)) { plan -> RoadmapTimelineCard(plan) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onNavigateToSyllabus) { Text("Syllabus") }
                OutlinedButton(onClick = onNavigateToTests) { Text("Tests") }
                OutlinedButton(onClick = onNavigateToErrors) { Text("Errors") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onNavigateToFocus) { Text("Focus") }
                OutlinedButton(onClick = onNavigateToSettings) { Text("Settings") }
            }
        }
        reply?.let { r -> item { ElevatedCard { Text(r, Modifier.padding(14.dp)) } } }
    }
}
