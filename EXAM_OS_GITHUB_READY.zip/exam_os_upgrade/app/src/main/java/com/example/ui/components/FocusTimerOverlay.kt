package com.example.ui.components

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable fun FocusTimerOverlay() { /* Focus sessions are launched from the Focus screen and controlled by the AI action pipeline. */ }
