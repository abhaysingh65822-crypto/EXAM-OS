package com.example.domain.ai

import com.example.data.model.TopicStatus

enum class StudentIntent {
    SETUP_EXAM,
    UPDATE_PROGRESS,
    REPORT_WEAKNESS,
    REPORT_STRENGTH,
    CHANGE_AVAILABILITY,
    GENERATE_QUESTIONS,
    CREATE_MOCK,
    REBUILD_ROADMAP,
    WHAT_SHOULD_I_DO_NOW,
    SYNC_SYLLABUS,
    MODIFY_SYLLABUS,
    REPORT_MISSED_TASK,
    WHAT_IF_QUERY,
    LOCK_DAY,
    COMPLETE_DAY,
    START_SESSION,
    STOP_SESSION,
    ADD_SUBJECT,
    DELETE_SUBJECT,
    ADD_CHAPTER,
    DELETE_CHAPTER,
    UPDATE_EXAM_SETTINGS,
    SWITCH_CONTROL_MODE,
    RESET_ROADMAP,
    CLEAR_TEST_HISTORY,
    GENERAL_CHAT
}

enum class AiActionType {
    SETUP_EXAM_CURRICULUM,
    UPDATE_TOPIC_PROGRESS,
    UPDATE_WEAKNESS,
    UPDATE_AVAILABILITY,
    REBUILD_ROADMAP,
    GENERATE_TEST_QUESTIONS,
    CREATE_MOCK_TEST,
    SYNC_SYLLABUS,
    UNDO_LAST_ACTION,
    WHAT_IF_SIMULATION,
    LOCK_ROADMAP_DAY,
    COMPLETE_ROADMAP_DAY,
    START_STUDY_SESSION,
    STOP_STUDY_SESSION,
    ADD_SUBJECT,
    DELETE_SUBJECT,
    ADD_CHAPTER,
    DELETE_CHAPTER,
    UPDATE_EXAM_SETTINGS,
    SWITCH_CONTROL_MODE,
    RESET_ROADMAP,
    CLEAR_TEST_HISTORY
}

enum class ToolPermission {
    READ_ONLY,
    LOW_RISK_WRITE,
    CONFIRM_REQUIRED,
    DESTRUCTIVE
}

enum class IntentConfidence {
    HIGH,
    MEDIUM,
    LOW
}

data class ClassifiedIntent(
    val intent: StudentIntent,
    val confidence: IntentConfidence,
    val extractedEntities: Map<String, String> = emptyMap()
)

data class StructuredAiAction(
    val actionType: AiActionType,
    val permission: ToolPermission,
    val targetSubject: String = "",
    val targetChapter: String = "",
    val targetTopic: String = "",
    val targetStatus: TopicStatus? = null,
    val hoursAvailable: Float = 0f,
    val questionCount: Int = 0,
    val testDifficulty: String = "MIXED", // EASY, MEDIUM, HARD, MIXED
    val examName: String = "",
    val examDateEpochMs: Long = 0L,
    val details: String = "",
    val targetDayNumber: Int = 1,
    val durationMinutes: Int = 30,
    val targetTotalDays: Int = 366,
    val targetScore: String = "",
    val controlMode: com.example.data.model.UserControlMode = com.example.data.model.UserControlMode.AUTO,
    val weightagePct: Int = 25,
    val requiresUserConfirmation: Boolean = false
)

data class AiActionResult(
    val isSuccess: Boolean,
    val actionType: AiActionType,
    val summaryMessage: String,
    val changesApplied: List<String> = emptyList(),
    val nextActionGuidance: String = "",
    val auditId: Long = 0L,
    val rollbackData: String? = null
)

data class RoadmapSubTask(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val type: String = "PRACTICE", // LEARN, THEORY, PRACTICE, PYQ, REVISION, ACTIVE_RECALL, TEST, MOCK, ERROR_REPAIR, FORMULA_REVISION, BACKLOG, BUFFER, FINAL_REVISION
    val estimatedMinutes: Int = 30,
    val isCompleted: Boolean = false,
    val reason: String = ""
)

data class RoadmapDayPlan(
    val dayNumber: Int,
    val dateString: String,
    val subjectName: String,
    val chapterName: String,
    val topicName: String,
    val taskType: String, // LEARN, PRACTICE, PYQ, REVISION, ACTIVE_RECALL, TEST, MOCK, ERROR_REPAIR, FORMULA_REVISION, BACKLOG, BUFFER, FINAL_REVISION
    val durationMinutes: Int,
    val pyqTarget: Int = 0,
    val reason: String,
    val phase: String = "LEARNING", // FOUNDATION, LEARNING, PRACTICE, PYQ, REVISION, MOCK, FINAL_REVISION, EXAM_READY
    val taskTitle: String = "",
    val description: String = "",
    val priority: String = "HIGH", // CRITICAL, HIGH, MEDIUM, LOW
    val status: String = "PENDING", // PENDING, IN_PROGRESS, COMPLETED, SKIPPED
    val dependencies: String = "",
    val revisionDue: Boolean = false,
    val questionTarget: Int = 15,
    val isCompleted: Boolean = false,
    val lockedByUser: Boolean = false,
    val subTasks: List<RoadmapSubTask> = emptyList()
)

data class WhatIfResult(
    val scenarioQuery: String,
    val proposedDailyHours: Float,
    val totalAvailableHours: Float,
    val requiredWorkloadHours: Float,
    val isFeasible: Boolean,
    val projectedCompletionDays: Int,
    val bufferDeltaPct: Float,
    val analysisNotes: List<String>
)

data class SyllabusSyncDiff(
    val examName: String,
    val missingSubjects: List<String>,
    val extraSubjects: List<String>,
    val missingChapters: List<String>,
    val extraChapters: List<String>,
    val missingTopics: List<String>,
    val conflicts: List<String>
)
