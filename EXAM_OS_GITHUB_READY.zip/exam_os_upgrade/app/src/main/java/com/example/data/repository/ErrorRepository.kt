package com.example.data.repository

import com.example.data.db.ErrorLogEntity
import com.example.data.db.ExamDao
import com.example.data.model.ErrorType
import kotlinx.coroutines.flow.Flow

data class ErrorCategoryStats(
    val errorType: ErrorType,
    val count: Int,
    val percentage: Float
)

class ErrorRepository(private val dao: ExamDao) {

    val allErrorsFlow: Flow<List<ErrorLogEntity>> = dao.getAllErrorsFlow()
    val unrepairedErrorsFlow: Flow<List<ErrorLogEntity>> = dao.getUnrepairedErrorsFlow()

    suspend fun logError(
        examId: Long,
        subjectName: String,
        chapterName: String,
        topicName: String,
        errorType: ErrorType,
        questionSnippet: String,
        studentMistake: String,
        correctionNote: String
    ): Long {
        val entity = ErrorLogEntity(
            examId = examId,
            subjectName = subjectName,
            chapterName = chapterName,
            topicName = topicName,
            errorType = errorType,
            questionSnippet = questionSnippet,
            studentMistake = studentMistake,
            correctionNote = correctionNote
        )
        return dao.insertErrorLog(entity)
    }

    suspend fun markRepaired(errorId: Long) {
        val errors = dao.getAllStudySessions() // placeholder query to avoid unused error
        // Fetch all error logs to find matching
        // In DAO, update error log
    }

    fun computeErrorDistribution(errors: List<ErrorLogEntity>): List<ErrorCategoryStats> {
        if (errors.isEmpty()) return emptyList()
        val total = errors.size.toFloat()
        val grouped = errors.groupBy { it.errorType }
        return ErrorType.values().mapNotNull { type ->
            val count = grouped[type]?.size ?: 0
            if (count > 0) {
                ErrorCategoryStats(type, count, (count / total) * 100f)
            } else null
        }.sortedByDescending { it.count }
    }
}
