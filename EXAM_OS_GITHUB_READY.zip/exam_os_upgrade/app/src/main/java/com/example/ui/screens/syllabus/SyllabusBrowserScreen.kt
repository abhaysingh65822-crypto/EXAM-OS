package com.example.ui.screens.syllabus

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.ExamOsViewModel

@Composable
fun SyllabusBrowserScreen(viewModel: ExamOsViewModel, onBack: () -> Unit) {
    val profile by viewModel.activeProfile.collectAsState()
    val chapters by viewModel.weakTopics.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Syllabus", style = MaterialTheme.typography.headlineSmall); TextButton(onClick = onBack) { Text("Back") } }
        Text(profile?.examName ?: "No active exam")
        Spacer(Modifier.height(12.dp))
        Text("Weak / revision topics", style = MaterialTheme.typography.titleLarge)
        LazyColumn { items(chapters) { Text("• ${it.name} — ${it.masteryScore}%", Modifier.padding(8.dp)) } }
    }
}
