package com.example.domain.roadmap

import com.example.data.db.ExamChapterEntity
import com.example.data.db.ExamProfileEntity
import com.example.data.db.ExamSubjectEntity
import com.example.data.db.RoadmapPlanVersionEntity
import com.example.data.db.StudentAvailabilityEntity
import com.example.data.model.ExamPhase
import com.example.data.model.TopicStatus
import com.example.domain.CountdownStrategyEngine
import com.example.domain.ai.RoadmapDayPlan
import com.example.domain.ai.WhatIfResult
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object DynamicRoadmapEngine {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun generateDayWiseRoadmap(
        profile: ExamProfileEntity,
        subjects: List<ExamSubjectEntity>,
        chapters: List<ExamChapterEntity>,
        availability: StudentAvailabilityEntity?,
        reasonForGeneration: String = "Autonomous Roadmap Generation",
        currentVersionNumber: Int = 1,
        targetTotalDays: Int? = null
    ): Pair<List<RoadmapDayPlan>, RoadmapPlanVersionEntity> {
        val daysRemaining = CountdownStrategyEngine.getDaysRemaining(profile.targetExamDateEpochMs).coerceAtLeast(1)
        val defaultDailyHours = availability?.defaultDailyHours ?: (profile.historicalDailyAverageMinutes / 60.0f).coerceAtLeast(2.5f)
        val weekendDailyHours = availability?.weekendDailyHours ?: 5.0f

        // Parse custom hours overrides (e.g. tomorrow: 2.0)
        val customOverrides = mutableMapOf<String, Float>()
        if (!availability?.customDayHoursJson.isNullOrBlank()) {
            try {
                val json = JSONObject(availability!!.customDayHoursJson)
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    customOverrides[key] = json.getDouble(key).toFloat()
                }
            } catch (_: Exception) {}
        }

        // Comprehensive default chapters if database is newly initialized
        val fallbackChapters = listOf(
            ExamChapterEntity(id = 101, subjectId = 1, name = "Real Numbers", importance = "HIGH", masteryScore = 40, pyqQuestionCount = 25),
            ExamChapterEntity(id = 102, subjectId = 1, name = "Polynomials", importance = "HIGH", masteryScore = 55, pyqQuestionCount = 30),
            ExamChapterEntity(id = 103, subjectId = 1, name = "Linear Equations in Two Variables", importance = "HIGH", masteryScore = 50, pyqQuestionCount = 35),
            ExamChapterEntity(id = 104, subjectId = 1, name = "Quadratic Equations", importance = "HIGH", masteryScore = 45, pyqQuestionCount = 40),
            ExamChapterEntity(id = 105, subjectId = 1, name = "Arithmetic Progressions", importance = "HIGH", masteryScore = 60, pyqQuestionCount = 30),
            ExamChapterEntity(id = 106, subjectId = 1, name = "Triangles & Geometric Proofs", importance = "HIGH", masteryScore = 35, pyqQuestionCount = 45),
            ExamChapterEntity(id = 107, subjectId = 1, name = "Coordinate Geometry", importance = "MEDIUM", masteryScore = 65, pyqQuestionCount = 25),
            ExamChapterEntity(id = 108, subjectId = 1, name = "Introduction to Trigonometry", importance = "HIGH", masteryScore = 40, pyqQuestionCount = 50),
            ExamChapterEntity(id = 109, subjectId = 1, name = "Applications of Trigonometry", importance = "HIGH", masteryScore = 48, pyqQuestionCount = 30),
            ExamChapterEntity(id = 110, subjectId = 1, name = "Circles & Tangent Theorems", importance = "MEDIUM", masteryScore = 50, pyqQuestionCount = 25),
            ExamChapterEntity(id = 111, subjectId = 1, name = "Surface Areas & Volumes", importance = "HIGH", masteryScore = 45, pyqQuestionCount = 35),
            ExamChapterEntity(id = 112, subjectId = 1, name = "Statistics & Probability", importance = "MEDIUM", masteryScore = 70, pyqQuestionCount = 30),
            ExamChapterEntity(id = 113, subjectId = 2, name = "Chemical Reactions & Equations", importance = "HIGH", masteryScore = 50, pyqQuestionCount = 30),
            ExamChapterEntity(id = 114, subjectId = 2, name = "Acids, Bases & Salts", importance = "HIGH", masteryScore = 45, pyqQuestionCount = 35),
            ExamChapterEntity(id = 115, subjectId = 2, name = "Metals & Non-Metals", importance = "HIGH", masteryScore = 40, pyqQuestionCount = 30),
            ExamChapterEntity(id = 116, subjectId = 2, name = "Carbon & Its Compounds", importance = "HIGH", masteryScore = 35, pyqQuestionCount = 45),
            ExamChapterEntity(id = 117, subjectId = 2, name = "Life Processes: Nutrition & Respiration", importance = "HIGH", masteryScore = 55, pyqQuestionCount = 40),
            ExamChapterEntity(id = 118, subjectId = 2, name = "Control & Coordination", importance = "MEDIUM", masteryScore = 45, pyqQuestionCount = 25),
            ExamChapterEntity(id = 119, subjectId = 2, name = "How Do Organisms Reproduce?", importance = "HIGH", masteryScore = 50, pyqQuestionCount = 35),
            ExamChapterEntity(id = 120, subjectId = 2, name = "Heredity & Evolution", importance = "MEDIUM", masteryScore = 52, pyqQuestionCount = 25),
            ExamChapterEntity(id = 121, subjectId = 2, name = "Light: Reflection & Refraction", importance = "HIGH", masteryScore = 40, pyqQuestionCount = 45),
            ExamChapterEntity(id = 122, subjectId = 2, name = "The Human Eye & Colourful World", importance = "MEDIUM", masteryScore = 60, pyqQuestionCount = 20),
            ExamChapterEntity(id = 123, subjectId = 2, name = "Electricity & Circuit Laws", importance = "HIGH", masteryScore = 38, pyqQuestionCount = 50),
            ExamChapterEntity(id = 124, subjectId = 2, name = "Magnetic Effects of Electric Current", importance = "HIGH", masteryScore = 42, pyqQuestionCount = 35),
            ExamChapterEntity(id = 125, subjectId = 2, name = "Our Environment", importance = "LOW", masteryScore = 75, pyqQuestionCount = 15)
        )

        val workingChapters = if (chapters.isNotEmpty()) chapters else fallbackChapters
        val sortedChapters = workingChapters.sortedWith(
            compareByDescending<ExamChapterEntity> { it.importance == "HIGH" }
                .thenBy { it.masteryScore }
        )

        val dayPlans = mutableListOf<RoadmapDayPlan>()
        val cal = Calendar.getInstance()
        var totalAllocatedMinutes = 0

        // Max making power: supports up to 366 days creating power!
        val maxRoadmapDays = (targetTotalDays ?: daysRemaining.toInt()).coerceIn(1, minOf(366, daysRemaining.toInt()))

        for (day in 1..maxRoadmapDays) {
            val dateStr = dateFormat.format(cal.time)
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            val isWeekend = (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY)

            val availableHours = customOverrides[dateStr]
                ?: (if (day == 1 && customOverrides.containsKey("tomorrow")) customOverrides["tomorrow"]!!
                    else if (isWeekend) weekendDailyHours else defaultDailyHours)

            val dailyMinutes = (availableHours * 60).roundToInt().coerceAtLeast(60)
            totalAllocatedMinutes += dailyMinutes

            val daysLeftFromHere = maxRoadmapDays - day
            val phaseEnum = CountdownStrategyEngine.determinePhase(daysLeftFromHere.toLong())

            // Progressive 6-stage trajectory across up to 366 days
            val phaseName = when {
                day <= (maxRoadmapDays * 0.25).toInt().coerceAtLeast(5) -> "FOUNDATION"
                day <= (maxRoadmapDays * 0.55).toInt() -> "DEEP_PRACTICE"
                day <= (maxRoadmapDays * 0.80).toInt() -> "PYQ_MARATHON"
                daysLeftFromHere <= 1 -> "FINAL_REVISION"
                daysLeftFromHere <= 7 -> "PEAK_SPRINT"
                daysLeftFromHere <= 14 -> "MOCK_SIMULATION"
                day % 7 == 0 -> "WEEKLY_MOCK"
                day % 6 == 0 -> "SPACED_REVISION"
                else -> "LEARNING"
            }

            // Chapter rotation with multiple pedagogical depth cycles
            val chapterIdx = ((day - 1) / 2) % sortedChapters.size
            val chap = sortedChapters[chapterIdx]
            val chapName = chap.name
            val subjectName = subjects.find { it.id == chap.subjectId }?.name
                ?: if (chap.name.contains("Reaction") || chap.name.contains("Acid") || chap.name.contains("Metal") ||
                    chap.name.contains("Carbon") || chap.name.contains("Life") || chap.name.contains("Light") ||
                    chap.name.contains("Electricity") || chap.name.contains("Eye") || chap.name.contains("Organism") ||
                    chap.name.contains("Environment")) "Science" else "Mathematics"

            val cycleNumber = ((day - 1) / (sortedChapters.size * 2)) + 1

            // Dynamic task generation based on day rhythm and phase
            val isWeeklyMockDay = (day % 7 == 0)
            val isRevisionDay = (day % 6 == 0 && !isWeeklyMockDay)

            val (taskType, reason, duration, pyqs, topicTarget) = when {
                daysLeftFromHere <= 1 -> {
                    Quintup(
                        "FINAL_REVISION",
                        "Final 24h: Exam hall strategy, sleep & rest protection, calm formula overview",
                        dailyMinutes.coerceAtMost(120),
                        0,
                        "Formula Index & Exam Day Calm Readiness"
                    )
                }
                daysLeftFromHere <= 7 -> {
                    Quintup(
                        "PEAK_SPRINT",
                        "Final 7d: High-yield formulas, mistake log surgery & rapid active recall",
                        dailyMinutes,
                        15,
                        "$chapName: High-Yield Board Exam Formula Sprint"
                    )
                }
                daysLeftFromHere <= 14 || isWeeklyMockDay -> {
                    Quintup(
                        "MOCK",
                        if (isWeeklyMockDay) "Weekly Benchmark Mock: Speed calibration, negative marking check & error repair"
                        else "Simulation sprint: Full length mock test and rigorous diagnostic review",
                        dailyMinutes,
                        30,
                        if (isWeeklyMockDay) "Weekly Autonomous Mock Exam & Diagnostics" else "Full Syllabus Simulation Test"
                    )
                }
                isRevisionDay -> {
                    Quintup(
                        "REVISION",
                        "Spaced retention cycle: Re-solving past error logs and active recall flashcards",
                        dailyMinutes,
                        20,
                        "$chapName: Spaced Retention & Error Surgery"
                    )
                }
                phaseName == "FOUNDATION" -> {
                    Quintup(
                        "LEARN",
                        "Core foundation: Concept clarification, standard derivations & NCERT examples",
                        dailyMinutes,
                        15,
                        "$chapName: Core Concept Theory & Exemplar (Cycle $cycleNumber)"
                    )
                }
                phaseName == "DEEP_PRACTICE" -> {
                    Quintup(
                        "PRACTICE",
                        "Deep numerical drill: Advanced textbook problems, word problems & timed sets",
                        dailyMinutes,
                        25,
                        "$chapName: Advanced Application & Numerical Drills"
                    )
                }
                phaseName == "PYQ_MARATHON" -> {
                    Quintup(
                        "PYQ",
                        "10-Year Past Papers: Step-marking calibration and high-frequency board questions",
                        dailyMinutes,
                        30,
                        "$chapName: 10-Year Board PYQ Deep Dive"
                    )
                }
                else -> {
                    Quintup(
                        "PRACTICE",
                        "Standard problem-solving sets, textbook numericals & active recall",
                        dailyMinutes,
                        20,
                        "$chapName: Concept Application & Derivations"
                    )
                }
            }

            val subTaskList = mutableListOf<com.example.domain.ai.RoadmapSubTask>()
            val partTime = (duration / 3).coerceAtLeast(20)

            when (taskType) {
                "LEARN" -> {
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Core Theory & Concept Notes ($chapName)", type = "LEARN", estimatedMinutes = partTime))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Solve $pyqs NCERT & In-text Practice Problems", type = "PRACTICE", estimatedMinutes = partTime))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Active Recall & Formula Sheet Creation", type = "ACTIVE_RECALL", estimatedMinutes = (duration - (partTime * 2)).coerceAtLeast(15)))
                }
                "PRACTICE" -> {
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Timed Problem Set ($pyqs Questions)", type = "PRACTICE", estimatedMinutes = partTime * 2))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Analyze Mistakes & Revise Formulas", type = "ERROR_REPAIR", estimatedMinutes = (duration - (partTime * 2)).coerceAtLeast(15)))
                }
                "PYQ" -> {
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Solve $pyqs 10-Year Past Board Questions", type = "PYQ", estimatedMinutes = partTime * 2))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Evaluate Marking Scheme & Step Presentation", type = "TEST", estimatedMinutes = (duration - (partTime * 2)).coerceAtLeast(15)))
                }
                "REVISION" -> {
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Active Recall of Definitions, Diagrams & Rules", type = "ACTIVE_RECALL", estimatedMinutes = partTime))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Solve 15 High-Yield Tricky PYQs", type = "PYQ", estimatedMinutes = partTime))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Error Doctor Review for Weak Spots", type = "ERROR_REPAIR", estimatedMinutes = (duration - (partTime * 2)).coerceAtLeast(15)))
                }
                "MOCK" -> {
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Full Timed Sectional / Mock Paper ($subjectName)", type = "MOCK", estimatedMinutes = (duration - 30).coerceAtLeast(45)))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Post-Test Analysis & Diagnostic Error Log", type = "TEST", estimatedMinutes = 30))
                }
                else -> {
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "High-Yield Formula & Summary Review", type = "FORMULA_REVISION", estimatedMinutes = duration / 2))
                    subTaskList.add(com.example.domain.ai.RoadmapSubTask(title = "Mental Model Recall & Rest Protection", type = "BUFFER", estimatedMinutes = duration / 2))
                }
            }

            dayPlans.add(
                RoadmapDayPlan(
                    dayNumber = day,
                    dateString = dateStr,
                    subjectName = subjectName,
                    chapterName = if (taskType == "MOCK") "Weekly Mock Arena" else chapName,
                    topicName = topicTarget,
                    taskType = taskType,
                    taskTitle = if (taskType == "MOCK") "Weekly Mock: $subjectName" else "$subjectName: $chapName",
                    description = reason,
                    durationMinutes = duration,
                    pyqTarget = pyqs,
                    priority = if (chap.importance == "HIGH" || phaseEnum == ExamPhase.FINAL_7_DAYS || isWeeklyMockDay) "CRITICAL" else "HIGH",
                    reason = reason,
                    phase = phaseName,
                    status = if (day == 1) "IN_PROGRESS" else "PENDING",
                    subTasks = subTaskList
                )
            )

            cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        // Serialize into RoadmapPlanVersionEntity
        val jsonArray = JSONArray()
        dayPlans.forEach { p ->
            val obj = JSONObject()
            obj.put("day", p.dayNumber)
            obj.put("date", p.dateString)
            obj.put("subject", p.subjectName)
            obj.put("chapter", p.chapterName)
            obj.put("topic", p.topicName)
            obj.put("task", p.taskType)
            obj.put("taskTitle", p.taskTitle)
            obj.put("description", p.description)
            obj.put("duration", p.durationMinutes)
            obj.put("pyqTarget", p.pyqTarget)
            obj.put("priority", p.priority)
            obj.put("phase", p.phase)
            obj.put("status", p.status)
            obj.put("reason", p.reason)

            val subsArr = JSONArray()
            p.subTasks.forEach { st ->
                val sObj = JSONObject()
                sObj.put("id", st.id)
                sObj.put("title", st.title)
                sObj.put("type", st.type)
                sObj.put("minutes", st.estimatedMinutes)
                sObj.put("completed", st.isCompleted)
                subsArr.put(sObj)
            }
            obj.put("subTasks", subsArr)
            jsonArray.put(obj)
        }

        val totalHours = totalAllocatedMinutes / 60.0f
        val version = RoadmapPlanVersionEntity(
            examId = profile.id,
            versionNumber = currentVersionNumber,
            title = "Adaptive Roadmap v$currentVersionNumber",
            reason = reasonForGeneration,
            planDaysJson = jsonArray.toString(),
            totalHours = totalHours,
            dailyAverageHours = if (maxRoadmapDays > 0) totalHours / maxRoadmapDays else 3.5f
        )

        return Pair(dayPlans, version)
    }

    fun simulateWhatIfScenario(
        scenarioQuery: String,
        profile: ExamProfileEntity,
        chapters: List<ExamChapterEntity>,
        proposedDailyHours: Float
    ): WhatIfResult {
        val daysRemaining = CountdownStrategyEngine.getDaysRemaining(profile.targetExamDateEpochMs).coerceAtLeast(1)
        val totalWorkloadMinutes = chapters.sumOf { (it.pyqQuestionCount * 4) + 60 }
        val requiredWorkloadHours = totalWorkloadMinutes / 60.0f

        val totalAvailableHours = daysRemaining * proposedDailyHours
        val isFeasible = totalAvailableHours >= requiredWorkloadHours
        val projectedDaysNeeded = (requiredWorkloadHours / proposedDailyHours.coerceAtLeast(0.5f)).toInt()
        val bufferDeltaPct = ((totalAvailableHours - requiredWorkloadHours) / totalAvailableHours.coerceAtLeast(1f)) * 100f

        val notes = mutableListOf<String>()
        if (isFeasible) {
            notes.add("Projected curriculum completion in $projectedDaysNeeded days (${daysRemaining - projectedDaysNeeded} buffer days before exam).")
            notes.add("Safe margin to schedule 8 full mock tests and 3 spaced repetition review cycles.")
        } else {
            val deficit = (requiredWorkloadHours - totalAvailableHours)
            notes.add("Deficit: ${"%.1f".format(deficit)} hours short of full coverage at ${proposedDailyHours}h/day.")
            notes.add("Recommendation: Prioritize top 70% highest-weightage chapters to guarantee mastery of core scoring concepts.")
        }

        return WhatIfResult(
            scenarioQuery = scenarioQuery,
            proposedDailyHours = proposedDailyHours,
            totalAvailableHours = totalAvailableHours,
            requiredWorkloadHours = requiredWorkloadHours,
            isFeasible = isFeasible,
            projectedCompletionDays = projectedDaysNeeded,
            bufferDeltaPct = bufferDeltaPct,
            analysisNotes = notes
        )
    }

    fun parseRoadmapFromVersion(version: RoadmapPlanVersionEntity): List<RoadmapDayPlan> {
        val list = mutableListOf<RoadmapDayPlan>()
        try {
            val jsonArray = JSONArray(version.planDaysJson)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val subTasksList = mutableListOf<com.example.domain.ai.RoadmapSubTask>()
                if (obj.has("subTasks")) {
                    val sArr = obj.getJSONArray("subTasks")
                    for (si in 0 until sArr.length()) {
                        val sObj = sArr.getJSONObject(si)
                        subTasksList.add(
                            com.example.domain.ai.RoadmapSubTask(
                                id = sObj.optString("id", java.util.UUID.randomUUID().toString()),
                                title = sObj.optString("title", "Practice Task"),
                                type = sObj.optString("type", "PRACTICE"),
                                estimatedMinutes = sObj.optInt("minutes", 30),
                                isCompleted = sObj.optBoolean("completed", false)
                            )
                        )
                    }
                }

                list.add(
                    RoadmapDayPlan(
                        dayNumber = obj.optInt("day", i + 1),
                        dateString = obj.optString("date", ""),
                        subjectName = obj.optString("subject", "General"),
                        chapterName = obj.optString("chapter", "Core Chapter"),
                        topicName = obj.optString("topic", "Topic Practice"),
                        taskType = obj.optString("task", "PRACTICE"),
                        taskTitle = obj.optString("taskTitle", obj.optString("chapter", "")),
                        description = obj.optString("description", ""),
                        durationMinutes = obj.optInt("duration", 60),
                        pyqTarget = obj.optInt("pyqTarget", 15),
                        priority = obj.optString("priority", "HIGH"),
                        reason = obj.optString("reason", "Scheduled based on exam syllabus"),
                        phase = obj.optString("phase", "LEARNING"),
                        status = obj.optString("status", if (i == 0) "IN_PROGRESS" else "PENDING"),
                        subTasks = subTasksList
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun serializeRoadmapToJson(days: List<RoadmapDayPlan>): String {
        val jsonArray = JSONArray()
        days.forEach { p ->
            val obj = JSONObject()
            obj.put("day", p.dayNumber)
            obj.put("date", p.dateString)
            obj.put("subject", p.subjectName)
            obj.put("chapter", p.chapterName)
            obj.put("topic", p.topicName)
            obj.put("task", p.taskType)
            obj.put("taskTitle", p.taskTitle)
            obj.put("description", p.description)
            obj.put("duration", p.durationMinutes)
            obj.put("pyqTarget", p.pyqTarget)
            obj.put("priority", p.priority)
            obj.put("phase", p.phase)
            obj.put("status", p.status)
            obj.put("reason", p.reason)
            obj.put("lockedByUser", p.lockedByUser)
            obj.put("isCompleted", p.isCompleted)
            val subsArr = JSONArray()
            p.subTasks.forEach { st ->
                val sObj = JSONObject()
                sObj.put("id", st.id)
                sObj.put("title", st.title)
                sObj.put("type", st.type)
                sObj.put("minutes", st.estimatedMinutes)
                sObj.put("completed", st.isCompleted)
                subsArr.put(sObj)
            }
            obj.put("subTasks", subsArr)
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }

    private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
    private data class Quintup<A, B, C, D, E>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E)
}
