package com.example.data.repository

import com.example.data.db.ExamDao
import com.example.data.db.StudySessionEntity
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

data class StudyAnalytics(
    val todayMinutes: Int,
    val thisWeekMinutes: Int,
    val totalFocusedMinutes: Int,
    val averageSessionMinutes: Int,
    val totalSessionsCount: Int,
    val overallEfficiencyPct: Int
)

class StudySessionRepository(private val dao: ExamDao) {

    val allSessionsFlow: Flow<List<StudySessionEntity>> = dao.getAllStudySessionsFlow()

    suspend fun recordStudySession(session: StudySessionEntity): Long {
        return dao.insertStudySession(session)
    }

    suspend fun computeAnalytics(): StudyAnalytics {
        val sessions = dao.getAllStudySessions()
        if (sessions.isEmpty()) {
            return StudyAnalytics(
                todayMinutes = 0,
                thisWeekMinutes = 0,
                totalFocusedMinutes = 0,
                averageSessionMinutes = 0,
                totalSessionsCount = 0,
                overallEfficiencyPct = 100
            )
        }

        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfToday = cal.timeInMillis

        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        val startOfWeek = cal.timeInMillis

        var todayMinutes = 0
        var thisWeekMinutes = 0
        var totalFocused = 0
        var totalActual = 0

        for (s in sessions) {
            totalFocused += s.focusedDurationMinutes
            totalActual += s.actualDurationMinutes
            if (s.timestampEpochMs >= startOfToday) {
                todayMinutes += s.focusedDurationMinutes
            }
            if (s.timestampEpochMs >= startOfWeek) {
                thisWeekMinutes += s.focusedDurationMinutes
            }
        }

        val avgSession = if (sessions.isNotEmpty()) totalFocused / sessions.size else 0
        val efficiency = if (totalActual > 0) ((totalFocused.toFloat() / totalActual) * 100).toInt().coerceIn(10, 100) else 100

        return StudyAnalytics(
            todayMinutes = todayMinutes,
            thisWeekMinutes = thisWeekMinutes,
            totalFocusedMinutes = totalFocused,
            averageSessionMinutes = avgSession,
            totalSessionsCount = sessions.size,
            overallEfficiencyPct = efficiency
        )
    }
}
