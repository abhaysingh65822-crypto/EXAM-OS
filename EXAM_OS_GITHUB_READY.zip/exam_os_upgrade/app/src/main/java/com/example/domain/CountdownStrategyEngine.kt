package com.example.domain

import com.example.data.db.DailyPlanTaskEntity
import com.example.data.db.ExamChapterEntity
import com.example.data.db.ExamProfileEntity
import com.example.data.db.ExamTopicEntity
import com.example.data.db.FocusSessionEntity
import com.example.data.db.RevisionItemEntity
import com.example.data.db.StudySessionEntity
import com.example.data.model.ExamPhase
import com.example.data.model.FeasibilityReport
import com.example.data.model.NextActionRecommendation
import com.example.data.model.TopicStatus
import kotlin.math.roundToInt

object CountdownStrategyEngine {

    fun getDaysRemaining(targetDateEpochMs: Long): Long {
        val diff = targetDateEpochMs - System.currentTimeMillis()
        return (diff / (1000L * 60 * 60 * 24)).coerceAtLeast(0)
    }

    fun determinePhase(daysRemaining: Long): ExamPhase {
        return when {
            daysRemaining <= 1 -> ExamPhase.FINAL_24_HOURS
            daysRemaining <= 7 -> ExamPhase.FINAL_7_DAYS
            daysRemaining <= 14 -> ExamPhase.FINAL_14_DAYS
            daysRemaining <= 45 -> ExamPhase.LATE_INTENSIVE
            daysRemaining <= 120 -> ExamPhase.MID_PREPARATION
            else -> ExamPhase.EARLY_FOUNDATION
        }
    }

    fun getPhaseGuidance(phase: ExamPhase): Pair<String, String> {
        return when (phase) {
            ExamPhase.EARLY_FOUNDATION -> Pair(
                "Foundation Building Mode",
                "Deep theory comprehension, foundational textbook derivation & structured chapter practice."
            )
            ExamPhase.MID_PREPARATION -> Pair(
                "Mixed Practice & Spaced Revision",
                "PYQ problem sets, interleaved multi-topic questions & scheduled spaced repetition."
            )
            ExamPhase.LATE_INTENSIVE -> Pair(
                "Exam Simulation & Weakness Repair",
                "Full-length timed mock tests, rapid error analysis & targeted weak chapter recovery."
            )
            ExamPhase.FINAL_14_DAYS -> Pair(
                "High-Yield Recall & Error Doctor",
                "High-weightage topic consolidation, mock test pattern refinement & mistake log repair."
            )
            ExamPhase.FINAL_7_DAYS -> Pair(
                "Strict Revision & Confidence Lock",
                "Strictly ZERO heavy new concepts. Formula flashcards, previous mistakes & sleep protection."
            )
            ExamPhase.FINAL_24_HOURS -> Pair(
                "Readiness & Mental Prime",
                "Light formula scanning, admit card/stationery verification & 8+ hours deep rest."
            )
        }
    }
}

object PlanFeasibilityEngine {

    fun evaluateFeasibility(
        daysRemaining: Long,
        totalRequiredMinutes: Int,
        historicalDailyAverageMinutes: Int = 180
    ): FeasibilityReport {
        val safeDays = daysRemaining.coerceAtLeast(1)
        val dailyCapacityMinutes = if (historicalDailyAverageMinutes > 0) historicalDailyAverageMinutes else 180
        val totalAvailableMinutes = safeDays * dailyCapacityMinutes

        val requiredHours = totalRequiredMinutes / 60.0f
        val availableHours = totalAvailableMinutes / 60.0f
        val dailyRequiredHours = requiredHours / safeDays.toFloat()
        val realisticDailyHours = dailyCapacityMinutes / 60.0f
        val deficitHours = (requiredHours - availableHours).coerceAtLeast(0f)
        val isFeasible = deficitHours <= 0.05f

        val recommendations = mutableListOf<String>()
        if (isFeasible) {
            val buffer = ((availableHours - requiredHours) / availableHours * 100).coerceAtLeast(0f)
            recommendations.add("Current pace is fully realistic with a healthy ${buffer.roundToInt()}% time buffer.")
            recommendations.add("Maintain consistency with at least ${"%.1f".format(dailyRequiredHours)}h focused study daily.")
        } else {
            recommendations.add("Mathematical deficit detected: ${"%.1f".format(deficitHours)} hours short of complete curriculum.")
            recommendations.add("Deprioritize low-yield peripheral topics to recover ~${"%.1f".format(deficitHours * 0.4f)} hours.")
            recommendations.add("Increase weekend focus sessions by 90 minutes to bridge the capacity gap.")
            recommendations.add("Lock into high-frequency PYQs rather than exhaustive theoretical proofs.")
        }

        return FeasibilityReport(
            isFeasible = isFeasible,
            requiredTotalHours = requiredHours,
            availableTotalHours = availableHours,
            realisticDailyStudyHours = realisticDailyHours,
            deficitHours = deficitHours,
            bufferPercentage = if (availableHours > 0) ((availableHours - requiredHours) / availableHours * 100).coerceAtLeast(0f) else 0f,
            recommendations = recommendations
        )
    }
}

object NextActionEngine {

    fun computeNextAction(
        profile: ExamProfileEntity?,
        pendingTasks: List<DailyPlanTaskEntity>,
        overdueRevisions: List<RevisionItemEntity>,
        chapters: List<ExamChapterEntity>,
        topics: List<ExamTopicEntity>
    ): NextActionRecommendation {
        val daysLeft = if (profile != null) CountdownStrategyEngine.getDaysRemaining(profile.targetExamDateEpochMs) else 60

        // 1. If overdue revisions exist, priority #1 is spaced repetition recall
        if (overdueRevisions.isNotEmpty()) {
            val rev = overdueRevisions.first()
            return NextActionRecommendation(
                title = "Critical Recall: ${rev.topicName}",
                subject = rev.subjectName,
                chapter = rev.chapterName,
                topic = rev.topicName,
                taskType = "SPACED_REVISION",
                durationMinutes = 25,
                urgencyReason = "Spaced repetition interval overdue (Day ${rev.currentIntervalDay}). Forgetting curve risk is high.",
                expectedOutcome = "Consolidate neural retention to >85% and lock into long-term memory."
            )
        }

        // 2. If there are pending daily tasks for today
        if (pendingTasks.isNotEmpty()) {
            val task = pendingTasks.first()
            return NextActionRecommendation(
                title = "${task.subjectName} → ${task.taskType}: ${task.topicName}",
                subject = task.subjectName,
                chapter = task.chapterName,
                topic = task.topicName,
                taskType = task.taskType,
                durationMinutes = task.durationMinutes,
                urgencyReason = task.reason,
                expectedOutcome = task.expectedOutcome
            )
        }

        // 3. Fallback: Identify the highest-impact weak chapter
        val weakChapter = chapters.filter { it.importance == "HIGH" && it.masteryScore < 60 }
            .minByOrNull { it.masteryScore }
            ?: chapters.firstOrNull()

        if (weakChapter != null) {
            val matchingTopic = topics.firstOrNull { it.chapterId == weakChapter.id && it.status != TopicStatus.MASTERED }
            val topicName = matchingTopic?.name ?: "High-Yield Questions & Theory"
            return NextActionRecommendation(
                title = "Solve High-Yield PYQs: ${weakChapter.name}",
                subject = "Priority Domain",
                chapter = weakChapter.name,
                topic = topicName,
                taskType = "PYQ_PRACTICE",
                durationMinutes = 40,
                urgencyReason = "Exam in $daysLeft days. Chapter mastery is currently at ${weakChapter.masteryScore}%.",
                expectedOutcome = "Boost problem-solving velocity and repair recurring pattern errors."
            )
        }

        return NextActionRecommendation(
            title = "Rapid Formula & Concept Diagnostic",
            subject = "Curriculum Overview",
            chapter = "High-Yield Review",
            topic = "Core Concept Check",
            taskType = "DIAGNOSTIC",
            durationMinutes = 30,
            urgencyReason = "Calibrate baseline accuracy and discover emerging knowledge gaps.",
            expectedOutcome = "Benchmark current readiness index across active subjects."
        )
    }
}

object BehaviorLearningEngine {

    fun calculateCapacityAndEfficiency(
        studySessions: List<StudySessionEntity>,
        focusSessions: List<FocusSessionEntity>
    ): Pair<Int, Int> { // Returns: (RealisticDailyMinutes, FocusEfficiencyPct)
        if (studySessions.isEmpty()) {
            return Pair(180, 85) // default 3 hours, 85% focus
        }

        // Group study sessions by day
        val totalActualMinutes = studySessions.sumOf { it.actualDurationMinutes }
        val totalFocusedMinutes = studySessions.sumOf { it.focusedDurationMinutes }

        val focusEfficiency = if (totalActualMinutes > 0) {
            ((totalFocusedMinutes.toFloat() / totalActualMinutes) * 100).roundToInt().coerceIn(10, 100)
        } else 85

        val distinctDays = studySessions.map { it.timestampEpochMs / (1000L * 60 * 60 * 24) }.distinct().size.coerceAtLeast(1)
        val learnedDailyAverage = (totalFocusedMinutes / distinctDays).coerceIn(60, 600)

        return Pair(learnedDailyAverage, focusEfficiency)
    }
}
