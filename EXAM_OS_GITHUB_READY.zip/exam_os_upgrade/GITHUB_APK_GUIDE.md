# GitHub APK build

This project includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.

1. Upload the project files to the **root** of a GitHub repository.
2. Open **Actions** → **Build EXAM OS APK**.
3. Choose **Run workflow** (or push to `main`/`master`).
4. After the run succeeds, open the workflow run and download the **exam-os-debug-apk** artifact.
5. Extract the artifact ZIP and install the `.apk` on Android.

The workflow uses JDK 17 and Gradle 9.3.1 and does not require `gradlew` because Gradle is provisioned by the GitHub Actions setup step.

The debug build uses Android's standard debug signing instead of requiring a private keystore in the repository.
