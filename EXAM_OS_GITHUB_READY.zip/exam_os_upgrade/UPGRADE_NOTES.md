# EXAM OS — Autonomous AI Upgrade

This package upgrades the supplied Android source rather than rebuilding it from scratch.

## Implemented in this pass
- Replaced the empty Compose UI/ViewModel files with a functional Android-first shell.
- Dashboard now exposes exam countdown, readiness, today's tasks, roadmap versions and the first roadmap days.
- Added a conversational AI control screen and registered-action pipeline integration.
- Added AI-assisted structured command extraction for messages the deterministic classifier cannot confidently map.
- Added image import from Android gallery into the existing vision pipeline.
- Added Android Keystore-backed Gemini key storage with one-time migration from the old plaintext preference.
- Disabled API-bearing HTTP logs in release builds.
- Roadmap horizon now defaults to the real exam countdown instead of always generating 366 days.
- Question-generation results now report the actual validated count rather than claiming a requested count was created when it was not.
- Preserved Google Search AI provider and optional Gemini provider architecture.
- Preserved Room data model, repositories, action registry and existing domain engines.

## Important engineering truth
The project cannot be compiled in this execution environment because the supplied archive does not contain `gradlew` and this environment does not have a Gradle installation. Therefore this archive is **source-upgraded but not claimed as build-verified** here.

Before publishing, open the project in Android Studio and run:
- `./gradlew testDebugUnitTest`
- `./gradlew lintDebug`
- `./gradlew assembleDebug`

The AI provider intentionally does not pretend that a static local response is live web search, and image analysis is only advertised when a real vision-capable provider/key is available.

## GitHub APK build support

Added `.github/workflows/android-apk.yml` for cloud APK builds. It provisions JDK 17 and Gradle 9.3.1, runs `assembleDebug`, and uploads the generated APK as a workflow artifact. The custom debug keystore requirement was removed so the debug build can use Android Gradle Plugin's standard debug signing.
